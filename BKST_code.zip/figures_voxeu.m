

close all

color_y = [0, 0.4470, 0.7410]; % blue
color_o = [0.8500, 0.3250, 0.0980]; % red

mycolor = [0.4660 0.6740 0.1880]; % green

colors = {color_y; color_o; color_y; color_o};
linestyles = {"-", "-", "--", "--"};

pos_fig1 = [300, 200, 800, 300];
pos_fig2 = [300, 200, 600, 300];

%% Figure 1 for VoxEU

t0 = 2;
t1 = 60;

figure
set(gcf, 'Position', pos_fig1);

% subplot 1
subplot(1, 2, 1)
hold on

X = zeros(T, 4);
X(:, 1:2) = SV_bm.d_h';
X(:, 3:4) = SV_ep.d_h';

X = X * 112;

for j = 1:4
    plot(X(t0:t1, j), linestyles{j}, 'color', colors{j}, 'LineWidth', 2)
end

title('Time spent at home', 'Interpreter', 'latex')
xlabel('Weeks', 'Interpreter', 'latex')
ylabel('Non-sleeping hours per week', 'Interpreter', 'latex')

grid on

set(gca, 'TickLabelInterpreter', 'latex')

% subplot 2
subplot(1, 2, 2)
hold on

X = zeros(T, 4);
X(:, 1:2) = SV_bm.M_infected';
X(:, 3:4) = SV_ep.M_infected';

for j = 1:4
    plot(X(t0:t1, j), linestyles{j}, 'color', colors{j}, 'LineWidth', 2)
end

title('Number of infected', 'Interpreter', 'latex')
xlabel('Weeks', 'Interpreter', 'latex')
ylabel('Fraction', 'Interpreter', 'latex')

legend({'Young', 'Old', 'Young (epidem.)', 'Old (epidem.)'}, 'Interpreter', 'latex')

set(gca, 'TickLabelInterpreter', 'latex')
% set(gca, 'FontSize', 10)

grid on

saveas(gcf, 'fig_voxeu1', 'emf')
saveas(gcf, 'fig_voxeu1', 'epsc')
saveas(gcf, 'fig_voxeu1', 'jpeg')

%% Figure 2 for VoxEU

y1 = zeros(7, 1);
y2 = zeros(7, 1);

x = [1 2 4 6 7 9 10];

% gdp
% y1(1) = sum(SV_bm.gdp(1:52)) / sum(SV_ep.gdp(1:52));
% y1(2) = sum(SV_ep.gdp(1:52)) / sum(SV_ep.gdp(1:52));
y1(1) = sum(SV_bm.gdp(1:52)) / (m_n*w*52);
y1(2) = sum(SV_ep.gdp(1:52)) / (m_n*w*52);

% GDP at the peak rel. to no-disease scenario
y1(3) = SV_bm.gdp(SV_bm.t_peak_I) / (m_n*w);

% dead long-run
y2(4) = SV_bm.M_d(i_young, T) * 1000;
y2(5) = SV_ep.M_d(i_young, T) * 1000;

y2(6) = SV_bm.M_d(i_old, T) * 1000;
y2(7) = SV_ep.M_d(i_old, T) * 1000;

% figure
colors2 = {0.5 * mycolor, mycolor, 0.5 * mycolor, 0.5 * mycolor, mycolor, 0.5 * mycolor, mycolor};

xnames = {'$$\begin{array}{c} \mbox{GDP 1 year} \\ \mbox{(left axis)} \end{array}$$', ...
    '$$\begin{array}{c} \mbox{GDP at peak} \\ \mbox{(left axis)} \end{array}$$', ...
    '$$\begin{array}{c} \mbox{Dead p/ 1,000} \\ \mbox{(young, right axis)} \end{array}$$', ...
    '$$\begin{array}{c} \mbox{Dead p/ 1,000} \\ \mbox{(old, right axis)} \end{array}$$'};

figure
set(gcf, 'Position', pos_fig2);
hold on

yyaxis left

for j = 1:length(y1)
    bar(x(j), y1(j), 'FaceColor', colors2{j});
end

ylabel('GDP relative to no-disease scenario', 'Interpreter', 'latex')

yyaxis right

for j = 1:length(y1)
    bar(x(j), y2(j), 'FaceColor', colors2{j});
end

set(gca, 'XTick', [1.5 4 6.5 9.5], 'XTickLabel', xnames, ...
    'YGrid', 'on', 'XGrid', 'off', ...
    'TickLabelInterpreter','latex');

ax = gca;
ax.YAxis(1).Color = 'k';
ax.YAxis(2).Color = 'k';

leg = legend({'Benchmark', 'Epidemiological'}, 'location', 'north', 'Interpreter', 'latex');
pos = get(leg, 'Position');
pos(1) = pos(1) * 1.2;
set(leg, 'position', pos)

% set(gca, 'FontSize', 10)

saveas(gcf, 'fig_voxeu2', 'emf')
saveas(gcf, 'fig_voxeu2', 'epsc')
saveas(gcf, 'fig_voxeu2', 'jpeg')

%% Figure 3 for VoxEU

t0 = 2;
t1 = 100;

figure
set(gcf, 'Position', pos_fig1);

% subplot 1
subplot(1, 2, 1)
hold on

X = zeros(T, 4);
X(:, 1:2) = SV_sh.d_h';
X(:, 3:4) = SV_bm.d_h';

X = X * 112;

for j = 1:4
    plot(X(t0:t1, j), linestyles{j}, 'color', colors{j}, 'LineWidth', 2)
end

title('Time spent at home', 'Interpreter', 'latex')
xlabel('Weeks', 'Interpreter', 'latex')
ylabel('Non-sleeping hours per week', 'Interpreter', 'latex')

grid on

set(gca, 'TickLabelInterpreter','latex')

legend({'Young', 'Old', 'Young (benchmark)', 'Old (benchmark)'}, 'Location', 'east', 'Interpreter', 'latex')

% subplot 2
subplot(1, 2, 2)
hold on

X = zeros(T, 4);
X(:, 1:2) = SV_sh.M_infected';
X(:, 3:4) = SV_bm.M_infected';

for j = 1:4
    plot(X(t0:t1, j), linestyles{j}, 'color', colors{j}, 'LineWidth', 2)
end

title('Number of infected', 'Interpreter', 'latex')
xlabel('Weeks', 'Interpreter', 'latex')
ylabel('Fraction', 'Interpreter', 'latex')

set(gca, 'TickLabelInterpreter','latex')

grid on

saveas(gcf, 'fig_voxeu3', 'emf')
saveas(gcf, 'fig_voxeu3', 'epsc')
saveas(gcf, 'fig_voxeu3', 'jpeg')

%% Figure 4 for VoxEU

y1 = zeros(9, 1);
y2 = zeros(9, 1);

x = [1 2 3 5 6 7 9 10 11];

% gdp
% y1(1) = sum(SV_bm.gdp(1:52)) / sum(SV_bm.gdp(1:52));
% y1(2) = sum(SV_sh.gdp(1:52)) / sum(SV_bm.gdp(1:52));
% y1(3) = sum(SV_q.gdp(1:52)) / sum(SV_bm.gdp(1:52));
y1(1) = sum(SV_bm.gdp(1:52)) / (m_n*w*52);
y1(2) = sum(SV_sh.gdp(1:52)) / (m_n*w*52);
y1(3) = sum(SV_q.gdp(1:52)) / (m_n*w*52);

% dead long-run
y2(4) = SV_bm.M_d(i_young, T) * 1000;
y2(5) = SV_sh.M_d(i_young, T) * 1000;
y2(6) = SV_q.M_d(i_young, T) * 1000;

y2(7) = SV_bm.M_d(i_old, T) * 1000;
y2(8) = SV_sh.M_d(i_old, T) * 1000;
y2(9) = SV_q.M_d(i_young, T) * 1000;

% figure
colors2 = {0.25 * mycolor, 0.75 * mycolor, mycolor, 0.25 * mycolor, 0.75 * mycolor, mycolor, 0.25 * mycolor, 0.75 * mycolor, mycolor};

xnames = {'$$\begin{array}{c} \mbox{GDP 1 year} \\ \mbox{(left axis)} \end{array}$$', ...
    '$$\begin{array}{c} \mbox{Dead p/ 1,000} \\ \mbox{(young, right axis)} \end{array}$$', ...
    '$$\begin{array}{c} \mbox{Dead p/ 1,000} \\ \mbox{(old, right axis)} \end{array}$$'};

figure
set(gcf, 'Position', pos_fig2);
hold on

yyaxis left

for j = 1:length(y1)
    bar(x(j), y1(j), 'FaceColor', colors2{j});
end

ylabel('GDP relative to no-disease scenario', 'Interpreter', 'latex')

yyaxis right

for j = 1:length(y2)
    bar(x(j), y2(j), 'FaceColor', colors2{j});
end

set(gca, 'XTick', [2 6 10], 'XTickLabel', xnames, ...
    'YGrid', 'on', 'XGrid', 'off', ...
    'TickLabelInterpreter','latex');

ax = gca;
ax.YAxis(1).Color = 'k';
ax.YAxis(2).Color = 'k';

legend({'Benchmark', 'Shelter-at-home', 'Quarantine'}, 'Location', 'north', 'Interpreter', 'latex')

saveas(gcf, 'fig_voxeu4', 'emf')
saveas(gcf, 'fig_voxeu4', 'epsc')
saveas(gcf, 'fig_voxeu4', 'jpeg')























