% An economic model of the Covid-19 pandemic with young and old agents: 
% Behavior, testing and policies
% Luiz Brotherhood, Philipp Kircher, Cezar Santos, and Michèle Tertilt

clear all
clc

tic

% declares global variables
global wbar w gamma theta rho b xi_p i_young i_old Pi0 Pistar

%-------------------------------------------------------------------------%
%                                 Moments                                 %
%-------------------------------------------------------------------------%

m_n = 0.357; % work time in the no-disease case
m_l = 0.154; % leisure time in the no-disease case
m_x_over_n = 0.125; % x/n in the no-disease case
Z_data = 0.00032607; % hospital beds
zeta_data = 0.5;

%-------------------------------------------------------------------------%
%                           Technical parameters                          %
%-------------------------------------------------------------------------%

n_age = 2; % number of age groups
i_young = 1;
i_old = 2;
i_nosymptoms = 1;
i_symptoms = 2;
T = 4 * 52; % total number of weeks for the transition
toler = 1e-5;

%-------------------------------------------------------------------------%
%                               Parameters                                %
%-------------------------------------------------------------------------%

% parameters - demography
frac_old = 0.1602;
frac_young = 1 - frac_old;
frac_age = [frac_young, frac_old];

% parameters - utility
rho = -1.72; % 1/(1-rho) is the elasticity of subst bw goods and leisure time
theta = 0.03327394; % weight of goods in production function of leisure goods
gamma = 0.63589003; % utility weight on leisure goods
b = 6.5; % utility weight of being alive
time_discount = 0.96^(1/52); % discount factor
survival_young = 1;
survival_old = 0.95^(1/52);
lambda_h = 1.5654178; % utility weigth for home hours for healthy
lambda_i = 4.502474; % utility weigth for home hours for infected
% lambda_i = 2.1272223; % utility weigth for home hours for infected

% parameters - infection
initial_sick = 0.0001; % initial fraction of people of each age that is infected
Pistar_hat = 0.112766814; % hourly infection rate for the common cold
Pistar = 1 - exp(-Pistar_hat);
n_plus_l_s = 0.158159722; % n+l por sick people (affects aggregate infection)
Pi0 = 11.29;

% parameters - wages
w = 1; % basic hourly wage
wbar = w * 0.6 * m_n; % pension for old folks
tau = 0; % teleworking productivity

% parameters - disease
delta = zeros(n_age, 1); % prob. of dying cond. on developing covid-19 symptoms
delta(i_young) = 0.06553201;
delta(i_old) = 0.73799969;

delta2 = zeros(n_age, 1); % prob. dying if symptoms and no hospital bed
delta2(:) = 1;

alpha = zeros(n_age, 1); % prob. of developing symptoms
alpha(:) = 1;

phi = zeros(2, n_age); % prob. of recovering (2 is for whether you have symptoms or not)
phi(i_nosymptoms, i_young) = 0.96673931;
phi(i_nosymptoms, i_old) = 0.90896255;
phi(i_symptoms, i_young) = 0.28409091;
phi(i_symptoms, i_old) = 0.28409091;

Z = 1; % use this if I don't use hospital bed constraints
% Z = Z_data;

% t_vaccine = T + 1; % in case we don't want a vaccine
t_vaccine = 1.5 * 52;

% parameters - selective mixing
zeta = 0; % fraction of activities that are separated
vartheta = [frac_young, frac_old]; % fraction of space dedicated to given age group

% parameters - policy
lambda_p_i = zeros(n_age, T); % "lockdown" policy parameter
lambda_p_h = zeros(n_age, T); % "lockdown" policy parameter
lambda_p_r = zeros(n_age, T); % "lockdown" policy parameter
lambda_p_f = zeros(n_age, T); % "lockdown" policy parameter

xi_p = zeros(n_age, 1); % prob. of getting a test

%-------------------------------------------------------------------------%
%                                  Flags                                  %
%-------------------------------------------------------------------------%

flag_epidemiological = 0; % if 1, uses behavior in the case of no disease
flag_Pi = 0; % if 1, doesn't iterate on Pi and uses Pi stored in struct "SP"
flag_fake_young = 0; % if 1, value functions of young have the following variables of old agents: delta, phi, beta, alpha

%-------------------------------------------------------------------------%
%                             Runs something                              %
%-------------------------------------------------------------------------%

% variable that says what the code will do
do = 0;

if do==1 % static calibration
    
    calibration
    
elseif do==2 % statistic to calibrate b
    
    b = 4;
    
    equilibrium
    
    % increase in time at home in week 9 (young)
    X = 100 * (d_h(i_young, 9)/d_h(i_young, T) - 1);
    fprintf('increase in d in week 9 (young, pct. change): %.8f\n', X)
    
    % number of active cases
    X = 0;
    for i_age = 1:n_age
        X = X + frac_age(i_age) * (M_fi(i_age, 9) + M_i(i_age, 9) + M_s(i_age, 9));
    end
    fprintf('number of active cases in week 9 (fi+i+s): %.8f\n', X)
    
    % number of active cases (only M_s)
    X = 0;
    for i_age = 1:n_age
        X = X + frac_age(i_age) * M_s(i_age, 9);
    end
    fprintf('number of active cases in week 9 (counting only M_s): %.8f\n', X)
    
elseif do==3 % only runs equilibrium
    
    equilibrium

elseif do==4 % policies
    
    t_vaccine_vec = [T + 1, 1.5 * 52];
    b_vec = [6.5, 4]; % without beds, with beds
    Z_vec = [1, Z_data];
    
    for i_vacc = 1:length(t_vaccine_vec)
        t_vaccine = t_vaccine_vec(i_vacc);
        
        for i_Z = 1:length(Z_vec)
            Z = Z_vec(i_Z);
            b = b_vec(i_Z);
            
            filename_results_suffix = strcat(num2str(i_vacc), '_', num2str(i_Z));
            
            fprintf('=================\n')
            fprintf('i_vacc: %i, i_Z: %i\n', i_vacc, i_Z)
            fprintf('=================\n')
            
            policies
        end
    end
    
elseif do==5 % some figures
    
    % benchmark
    equilibrium
    SF = struct('M_i_all', M_i_all, 'M_h', M_h, 'M_fh', M_fh, 'M_fi', M_fi, 'M_f', M_f, 'M_i', M_i, 'M_s', M_s, 'M_r', M_r, 'M_d', M_d, 'I', I, 'c_h', c_h, 'n_h', n_h, 'l_h', l_h, 'x_h', x_h, 'd_h', d_h, 'c_f', c_f, 'n_f', n_f, 'l_f', l_f, 'x_f', x_f, 'd_f', d_f, 'pi_h_vec', pi_h_vec, 'pi_f_vec', pi_f_vec, 'pif_h_vec', pif_h_vec, 'pif_f_vec', pif_f_vec, 'gdp', gdp, 'prior_vec', prior_vec, 'v_h', v_h, 'c_i', c_i, 'n_i', n_i, 'l_i', l_i, 'x_i', x_i, 'd_i', d_i, 'v_i', v_i, 'c_r', c_r, 'n_r', n_r, 'l_r', l_r, 'x_r', x_r, 'd_r', d_r, 'v_r', v_r, 'v_f', v_f, 'gdp_pc', gdp_pc, 'Pi', Pi);

    % epidemiological
    flag_epidemiological = 1;
    
    equilibrium
    
    t0_fig = 1;
    t1_fig = 150;
    filename_fig_suffix = '_benchmark';
    figures_June29
    
    t0_fig = 1;
    t1_fig = 90;
    filename_fig_suffix = '_benchmark_78';
    figures_June29
    
    flag_epidemiological = 0;
    
    % SH90-a-26
    new_lambda = 21.437848; % 90% increase in d
    
    duration = 26;
    
    lambda_p_i(:,:) = 0;
    lambda_p_h(:,:) = 0;
    lambda_p_r(:,:) = 0;
    lambda_p_f(:,:) = 0;
            
    lambda_p_i(:, 1:duration) = max(new_lambda - lambda_i, 0);
    lambda_p_h(:, 1:duration) = max(new_lambda - lambda_h, 0);
    lambda_p_r(:, 1:duration) = max(new_lambda - lambda_h, 0);
    lambda_p_f(:, 1:duration) = max(new_lambda - lambda_h, 0);
    
    equilibrium
    
    t0_fig = 1;
    t1_fig = 150;
    filename_fig_suffix = '_SH90a26';
    figures_June29
    
    t0_fig = 1;
    t1_fig = 90;
    filename_fig_suffix = '_SH90a26_78';
    figures_June29
    
    % SH90-o-26
    new_lambda = 21.437848; % 90% increase in d
    
    duration = 26;
    
    lambda_p_i(:,:) = 0;
    lambda_p_h(:,:) = 0;
    lambda_p_r(:,:) = 0;
    lambda_p_f(:,:) = 0;
            
    lambda_p_i(i_old, 1:duration) = max(new_lambda - lambda_i, 0);
    lambda_p_h(i_old, 1:duration) = max(new_lambda - lambda_h, 0);
    lambda_p_r(i_old, 1:duration) = max(new_lambda - lambda_h, 0);
    lambda_p_f(i_old, 1:duration) = max(new_lambda - lambda_h, 0);
    
    equilibrium
    
    t0_fig = 1;
    t1_fig = 150;
    filename_fig_suffix = '_SH90o26';
    figures_June29
    
    t0_fig = 1;
    t1_fig = 90;
    filename_fig_suffix = '_SH90o26_78';
    figures_June29
    
    % Q90-a-50t
    xi_p(:) = 0.5;
    
    new_lambda = 21.437848; % 90% increase in d
    
    lambda_p_i(:, :) = max(new_lambda - lambda_i, 0);
    lambda_p_h(:, :) = 0;
    lambda_p_r(:, :) = 0;
    lambda_p_f(:, :) = 0;
    
    equilibrium
    
    t0_fig = 1;
    t1_fig = 150;
    filename_fig_suffix = '_Q90a50t';
    figures_June29
    
    t0_fig = 1;
    t1_fig = 90;
    filename_fig_suffix = '_Q90a50t_78';
    figures_June29
    
    % testing all
    xi_p(:) = 1;
    
    lambda_p_i(:, :) = 0;
    lambda_p_h(:, :) = 0;
    lambda_p_r(:, :) = 0;
    lambda_p_f(:, :) = 0;
    
    equilibrium
    
    t0_fig = 1;
    t1_fig = 150;
    filename_fig_suffix = '_testing_all';
    figures_June29
    
    t0_fig = 1;
    t1_fig = 90;
    filename_fig_suffix = '_testing_all_78';
    figures_June29
    
elseif do==6 % CFR
    
    % benchmark
    equilibrium
    
    % deaths old/deaths all
    ratio_deaths = M_d(i_old, :) * frac_old ./ (M_d(i_old, :) * frac_old + M_d(i_young, :) * frac_young);

    % case fatality rate
    CFR = zeros(3, T);
    CFR(1:2, :) = M_d ./ (M_d + M_rn);
    CFR(3, :) = (frac_young * M_d(i_young, :) + frac_old * M_d(i_old, :)) ./ ...
        (frac_young * (M_d(i_young, :) + M_rn(i_young, :)) + ...
         frac_old * (M_d(i_old, :) + M_rn(i_old, :)));
    
elseif do==7 % figures for VoxEU
    
    % benchmark
    equilibrium
    
    M_infected = M_fi + M_i + M_s;
    [~, t_peak_I] = max(I);
    SV_bm = struct('d_h', d_h, 'M_infected', M_infected, 'gdp', gdp, 'M_d', M_d, ...
        't_peak_I', t_peak_I);
    
    % epidem.
    flag_epidemiological = 1;
    equilibrium
    flag_epidemiological = 0;
    
    M_infected = M_fi + M_i + M_s;
    [~, t_peak_I] = max(I);
    SV_ep = struct('d_h', d_h, 'M_infected', M_infected, 'gdp', gdp, 'M_d', M_d, ...
        't_peak_I', t_peak_I);
    
    % SH90-a-26
    new_lambda = 21.437528;
    duration = 26;
    
    lambda_p_i(:,:) = 0;
    lambda_p_h(:,:) = 0;
    lambda_p_r(:,:) = 0;
    lambda_p_f(:,:) = 0;
    
    lambda_p_i(:, 1:duration) = max(new_lambda - lambda_i, 0);
    lambda_p_h(:, 1:duration) = max(new_lambda - lambda_h, 0);
    lambda_p_r(:, 1:duration) = max(new_lambda - lambda_h, 0);
    lambda_p_f(:, 1:duration) = max(new_lambda - lambda_h, 0);
    
    equilibrium
    
    M_infected = M_fi + M_i + M_s;
    [~, t_peak_I] = max(I);
    SV_sh = struct('d_h', d_h, 'M_infected', M_infected, 'gdp', gdp, 'M_d', M_d, ...
        't_peak_I', t_peak_I);
    
    % Q90-a-50t
    new_lambda = 21.437528;
    testing_intensity = 0.5;
    
    lambda_p_i(:,:) = max(new_lambda - lambda_i, 0);
    lambda_p_h(:,:) = 0;
    lambda_p_r(:,:) = 0;
    lambda_p_f(:,:) = 0;
    
    xi_p(:) = testing_intensity;
    
    equilibrium
    
    M_infected = M_fi + M_i + M_s;
    [~, t_peak_I] = max(I);
    SV_q = struct('d_h', d_h, 'M_infected', M_infected, 'gdp', gdp, 'M_d', M_d, ...
        't_peak_I', t_peak_I);
    
    % makes figures
    figures_voxeu

elseif do==8 % combo policies
    
    % do it with and without vaccine
%     t_vaccine = 52;
    
    % quarantine intensity
    new_lambda = 21.437528; % 90% increase in time at home
    lambda_p_i(:,:) = max(new_lambda - lambda_i, 0);
    
    % quarantine testing intensities
    testing_intensities = [0.25, 0.5, 0.75 1];
    
    % benchmark
    equilibrium
    results % saves results to csv
    
    % saves some variables of benchmark
    SB = struct('M_d', M_d, 'gdp', gdp, 'gdp_pc', gdp_pc, 't_peak_I', t_peak_I);
    SP = struct('Pi', Pi, 'I', I, 'M_s', M_s);
    
    % lockdown duration
    duration = 52;
    
    % lambda for lockdown
    new_lambda = 2.5722084; % 25% increase in time at home
    
    % loops over testing intensities and lockdown groups
    for i_testing = 1:length(testing_intensities)
        testing_intensity = testing_intensities(i_testing);
        
        xi_p(:) = testing_intensity;
        
        for i_group = 1:3
            lambda_p_h(:,:) = 0;
            lambda_p_r(:,:) = 0;
            lambda_p_f(:,:) = 0;
            
            if i_group==1
                lambda_p_h(:, 1:duration) = max(new_lambda - lambda_h, 0);
                lambda_p_r(:, 1:duration) = max(new_lambda - lambda_h, 0);
                lambda_p_f(:, 1:duration) = max(new_lambda - lambda_h, 0);
            elseif i_group==2
                lambda_p_h(i_young, 1:duration) = max(new_lambda - lambda_h, 0);
                lambda_p_r(i_young, 1:duration) = max(new_lambda - lambda_h, 0);
                lambda_p_f(i_young, 1:duration) = max(new_lambda - lambda_h, 0);
            else
                lambda_p_h(i_old, 1:duration) = max(new_lambda - lambda_h, 0);
                lambda_p_r(i_old, 1:duration) = max(new_lambda - lambda_h, 0);
                lambda_p_f(i_old, 1:duration) = max(new_lambda - lambda_h, 0);
            end
            
            % runs equilibrium and saves results to csv
            fprintf('%i, %i\n', i_testing, i_group)
            equilibrium
            results
        end
    end

elseif do==9 % figure for combo policies
    
    % quarantine intensity
    new_lambda = 21.437528; % 90% increase in time at home
    lambda_p_i(:,:) = max(new_lambda - lambda_i, 0);
    
    % testing intensities
    testing_intensities = 0:0.05:1;
    
    % lockdown durations
    durations = [12, 26, 52];
    
    % lambda for lockdown
    new_lambda = 2.5722084; % 25% increase in time at home
    
    % variable to store results
    DATA = zeros(length(testing_intensities), length(durations), 2, n_age, 2);
    
    % loop
    for i_vacc = 1:2
        if i_vacc==1
            t_vaccine = T + 1;
        else
            t_vaccine = 78;
        end
        
        for i_testing = 1:length(testing_intensities)
            testing_intensity = testing_intensities(i_testing);

            xi_p(:) = testing_intensity;

            for i_duration = 1:length(durations)
                duration = durations(i_duration);
                
                lambda_p_h(:,:) = 0;
                lambda_p_r(:,:) = 0;
                lambda_p_f(:,:) = 0;

                lambda_p_h(:, 1:duration) = max(new_lambda - lambda_h, 0);
                lambda_p_r(:, 1:duration) = max(new_lambda - lambda_h, 0);
                lambda_p_f(:, 1:duration) = max(new_lambda - lambda_h, 0);
                
                disp([i_vacc, i_testing, i_duration])
                equilibrium
                
                DATA(i_testing, i_duration, i_vacc, i_young, 1) = M_d(i_young, T);
                DATA(i_testing, i_duration, i_vacc, i_old, 1) = M_d(i_old, T);
                DATA(i_testing, i_duration, i_vacc, i_young, 2) = max(N_c_f(i_young, :));
                DATA(i_testing, i_duration, i_vacc, i_old, 2) = max(N_c_f(i_old, :));
            end
        end
    end
    
    save('DATA.mat', 'DATA');
    
%     load('DATA.mat', 'DATA');
    
    blue = [0, 0.4470, 0.7410]; % blue
    red = [0.8500, 0.3250, 0.0980]; % red
    colors = {blue, red};
    linespecs = {'-', '-o', '-d'};
    
    for i_vacc = 1:2
        for i_stat = 1:2

            figure
            hold on
            for i_duration = 1:length(durations)
                for i_age = 1:n_age
                    plot(testing_intensities, DATA(:, i_duration, i_vacc, i_age, i_stat), ...
                        linespecs{i_duration}, 'color', colors{i_age}, 'linewidth', 2)
                end
            end
            grid on
            
            filename = strcat(num2str(i_vacc), '_', num2str(i_stat));
            saveas(gcf, filename, 'jpg')
        end
    end
    
elseif do==10 % Ferguson's numbers
    
    % sets parameters
    phi(i_nosymptoms, i_young) = 0.991289141;
    phi(i_nosymptoms, i_old) = 0.893010253;
    phi(i_symptoms, i_young) = 0.284090909;
    phi(i_symptoms, i_old) = 0.284090909;
    delta(i_young) = 0.372680985;
    delta(i_old) = 0.371014263;
    alpha(:) = 1;
    Pi0 = 11.507;
    b = 6.5;
    
    % suffix for results csv file
    filename_results_suffix = 'ferguson';
    
    % benchmark equilibrium
    equilibrium
    
    % increase in time at home in week 9 (young)
    X = 100 * (d_h(i_young, 9)/d_h(i_young, T) - 1);
    fprintf('increase in d in week 9 (young, pct. change): %.8f\n', X)
    
    % saves results to csv
    results
    SB = struct('M_d', M_d, 'gdp', gdp, 'gdp_pc', gdp_pc, 't_peak_I', t_peak_I);
    
    % epidemiological model
    flag_epidemiological = 1;
    equilibrium
    results
    
elseif do==11 % no altruism
    
    % sets parameters
    lambda_i = lambda_h;
    b = 4.85;
    
    % benchmark equilibrium
    equilibrium
    
    % suffix for results csv file
    filename_results_suffix = 'no_altruism';
    
    % increase in time at home in week 9 (young)
    X = 100 * (d_h(i_young, 9)/d_h(i_young, T) - 1);
    fprintf('increase in d in week 9 (young, pct. change): %.8f\n', X)
    
    % saves results to csv
    results
    SB = struct('M_d', M_d, 'gdp', gdp, 'gdp_pc', gdp_pc, 't_peak_I', t_peak_I);
    
    % epidemiological model
    flag_epidemiological = 1;
    equilibrium
    results
    
elseif do==12 % late shelter-in-place
    
    % benchmark
    equilibrium
    
    filename_results_suffix = 'late_sh';
    results
    
    SB = struct('M_d', M_d, 'gdp', gdp, 'gdp_pc', gdp_pc, 't_peak_I', t_peak_I);
    SF = struct('M_i_all', M_i_all, 'M_h', M_h, 'M_fh', M_fh, 'M_fi', M_fi, 'M_f', M_f, 'M_i', M_i, 'M_s', M_s, 'M_r', M_r, 'M_d', M_d, 'I', I, 'c_h', c_h, 'n_h', n_h, 'l_h', l_h, 'x_h', x_h, 'd_h', d_h, 'c_f', c_f, 'n_f', n_f, 'l_f', l_f, 'x_f', x_f, 'd_f', d_f, 'pi_h_vec', pi_h_vec, 'pi_f_vec', pi_f_vec, 'pif_h_vec', pif_h_vec, 'pif_f_vec', pif_f_vec, 'gdp', gdp, 'prior_vec', prior_vec, 'v_h', v_h, 'c_i', c_i, 'n_i', n_i, 'l_i', l_i, 'x_i', x_i, 'd_i', d_i, 'v_i', v_i, 'c_r', c_r, 'n_r', n_r, 'l_r', l_r, 'x_r', x_r, 'd_r', d_r, 'v_r', v_r, 'v_f', v_f, 'gdp_pc', gdp_pc, 'Pi', Pi);
    
    % SH90-a-... (begins in week 9 and lasts for 12 weeks)
    new_lambda = 21.437848; % 90% increase in d
    
    lambda_p_i(:,:) = 0;
    lambda_p_h(:,:) = 0;
    lambda_p_r(:,:) = 0;
    lambda_p_f(:,:) = 0;
    
    lambda_p_i(:, 9:9+12) = max(new_lambda - lambda_i, 0);
    lambda_p_h(:, 9:9+12) = max(new_lambda - lambda_h, 0);
    lambda_p_r(:, 9:9+12) = max(new_lambda - lambda_h, 0);
    lambda_p_f(:, 9:9+12) = max(new_lambda - lambda_h, 0);
    
    equilibrium
    
    results
    
    filename_fig_suffix = '_late_sh';
    
    figures_June29
    
    
elseif do==13 % 1.5 year shelter-in-place
    
    % benchmark
    equilibrium
    
    filename_results_suffix = 'sh78';
    results
    
    SB = struct('M_d', M_d, 'gdp', gdp, 'gdp_pc', gdp_pc, 't_peak_I', t_peak_I);
    
    % SH...-a-78
    new_lambdas = [2.572233, 4.502474, 9.7052372, 21.437848]; % 25, 50, 75%, 90% increase in d
    
    for i_new_lambda = 1:length(new_lambdas)
        new_lambda = new_lambdas(i_new_lambda); % 90% increase in d
        
        lambda_p_i(:,:) = 0;
        lambda_p_h(:,:) = 0;
        lambda_p_r(:,:) = 0;
        lambda_p_f(:,:) = 0;

        lambda_p_i(:, 1:78) = max(new_lambda - lambda_i, 0);
        lambda_p_h(:, 1:78) = max(new_lambda - lambda_h, 0);
        lambda_p_r(:, 1:78) = max(new_lambda - lambda_h, 0);
        lambda_p_f(:, 1:78) = max(new_lambda - lambda_h, 0);

        equilibrium

        results
    end
    
    % SH50-y,o-78
    new_lambda = 4.502474;
    
    for i_age = 1:n_age
        lambda_p_i(:,:) = 0;
        lambda_p_h(:,:) = 0;
        lambda_p_r(:,:) = 0;
        lambda_p_f(:,:) = 0;

        lambda_p_i(i_age, 1:78) = max(new_lambda - lambda_i, 0);
        lambda_p_h(i_age, 1:78) = max(new_lambda - lambda_h, 0);
        lambda_p_r(i_age, 1:78) = max(new_lambda - lambda_h, 0);
        lambda_p_f(i_age, 1:78) = max(new_lambda - lambda_h, 0);
        
        equilibrium
        results
    end
    
elseif do==14 % some age externality exercises
    
    filename_results_suffix = 'age_ext';
    
    % benchmark
    equilibrium
    results
    
    SB = struct('M_d', M_d, 'gdp', gdp, 'gdp_pc', gdp_pc, 't_peak_I', t_peak_I);
    
    % testing all (normal)
    xi_p(:) = 1;
    
    equilibrium
    results
    
    SP = struct('Pi', Pi, 'I', I, 'M_s', M_s);
    
    % testing all (age ext. partial)
    flag_Pi = 1;
    flag_fake_young = 1;
    
    equilibrium
    results
    
    flag_Pi = 0;
    flag_fake_young = 0;
    
    % testing all (age ext. general)
    flag_fake_young = 1;
    
    equilibrium
    results
    
    flag_fake_young = 0;
    
    xi_p(:) = 0;
    
    % SH90-a-26 (normal)
    new_lambda = 21.437848;
    
    duration = 26;
    
    lambda_p_i(:,:) = 0;
    lambda_p_h(:,:) = 0;
    lambda_p_r(:,:) = 0;
    lambda_p_f(:,:) = 0;
    
    lambda_p_i(:, 1:duration) = max(new_lambda - lambda_i, 0);
    lambda_p_h(:, 1:duration) = max(new_lambda - lambda_h, 0);
    lambda_p_r(:, 1:duration) = max(new_lambda - lambda_h, 0);
    lambda_p_f(:, 1:duration) = max(new_lambda - lambda_h, 0);
    
    equilibrium
    results
    
    SP = struct('Pi', Pi, 'I', I, 'M_s', M_s);
    
    % SH90-a-26 (age ext. partial)
    flag_Pi = 1;
    flag_fake_young = 1;
    
    equilibrium
    results
    
    flag_Pi = 0;
    flag_fake_young = 0;
    
    % SH90-a-26 (age ext. general)
    flag_fake_young = 1;
    
    equilibrium
    results
    
    flag_fake_young = 0;
    
elseif do==15 % combination of policies
    
    filename_results_suffix = 'combination';
    
    % benchmark
    equilibrium
    results
    SB = struct('M_d', M_d, 'gdp', gdp, 'gdp_pc', gdp_pc, 't_peak_I', t_peak_I);
    
    % combination of policies
    testing_intensities = [0.25, 0.5];
    zetas = [0, 0.25, 0.5];
    duration = 78;
    
    lambda25 = 2.572233;
    lambda90 = 21.437848;
    
    lambda_p_i(:,:) = 0;
    lambda_p_h(:,:) = 0;
    lambda_p_r(:,:) = 0;
    lambda_p_f(:,:) = 0;
    
    lambda_p_i(:, 1:duration) = max(lambda90 - lambda_h, 0);
    lambda_p_h(:, 1:duration) = max(lambda25 - lambda_h, 0);
    lambda_p_r(:, 1:duration) = max(lambda25 - lambda_h, 0);
    lambda_p_f(:, 1:duration) = max(lambda25 - lambda_h, 0);
    
    for i_testing = 1:length(testing_intensities)
        testing_intensity = testing_intensities(i_testing);
        xi_p(:) = testing_intensity;
        
        for i_zeta = 1:length(zetas)
            zeta = zetas(i_zeta);
            
            equilibrium
            results
        end
    end
    
elseif do==16 % no natural deaths for the old
    
    filename_results_suffix = 'survival_old';
    
    survival_old = 1;
    
    % benchmark
    equilibrium
    results
    SB = struct('M_d', M_d, 'gdp', gdp, 'gdp_pc', gdp_pc, 't_peak_I', t_peak_I);
    
    % epidemiological
    flag_epidemiological = 1;
    equilibrium
    results
    
elseif do==17 % combination of policies (2)
    
    filename_results_suffix = 'combination2';
    
    % benchmark
    equilibrium
    results
    SB = struct('M_d', M_d, 'gdp', gdp, 'gdp_pc', gdp_pc, 't_peak_I', t_peak_I);
    
    % policy parameters
    xi_p(:) = 0.5;
    lambda90 = 21.437848;
    
    new_lambdas = [1.9042724, 2.572233]; % 10, 25
    durations = [52, 78];
    
    % combination2
    for i_lambda = 1:length(new_lambdas)
        new_lambda = new_lambdas(i_lambda);
        
        for i_duration = 1:length(durations)
            duration = durations(i_duration);
            
            lambda_p_i(:,:) = 0;
            lambda_p_h(:,:) = 0;
            lambda_p_r(:,:) = 0;
            lambda_p_f(:,:) = 0;
            
            lambda_p_i(:, 1:duration) = max(lambda90 - lambda_h, 0);
            lambda_p_h(:, 1:duration) = max(new_lambda - lambda_h, 0);
            lambda_p_r(:, 1:duration) = max(new_lambda - lambda_h, 0);
            lambda_p_f(:, 1:duration) = max(new_lambda - lambda_h, 0);
            
            equilibrium
            results
        end
    end
    
elseif do==18 % reruns simulations with tests (because we are reporting a new statistic)
    
    b_vec = [6.5, 4]; % without beds, with beds
    Z_vec = [1, Z_data];
    
    for i_Z = 1:length(Z_vec)
        Z = Z_vec(i_Z);
        b = b_vec(i_Z);
        
        filename_results_suffix = strcat('testing_', num2str(i_Z));
            
        fprintf('======\n')
        fprintf('i_Z: %i\n', i_Z)
        fprintf('======\n')

        policies
    end
    
elseif do==19 % some numbers for the "no disease" column in the benchmark results table
    
    % computes benchmark equilibrium
    equilibrium
    
    % initiates X
    X = [];
    
    % GDP at peak - rel. to BM
    x = m_n * w / gdp(t_peak_I);
    X = [X; x];
    
    % GDP 1 year - rel. to BM
    x = 52 * m_n * w / sum(gdp(1:52));
    X = [X; x];
    
    % hrs. home (yng) - peak
    x = 112 * d_h_term(i_young);
    X = [X; x];
    
    % hrs. home (old) - peak
    x = 112 * d_h_term(i_old);
    X = [X; x];
    
    % hrs. home (yng) - 6m
    x = 112 * d_h_term(i_young);
    X = [X; x];
    
    % hrs. home (old) - 6m
    x = 112 * d_h_term(i_old);
    X = [X; x];
    
    % value - healthy (yng)
    x = v_h_terminal(i_young);
    X = [X; x];
    
    % value - healthy (old)
    x = v_h_terminal(i_old);
    X = [X; x];
    
    % value - healthy (all)
    x = frac_young * v_h_terminal(i_young) + frac_old * v_h_terminal(i_old);
    X = [X; x];
    
end










toc









