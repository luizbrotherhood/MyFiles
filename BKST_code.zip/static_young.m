function [x,n,l,d] = static_young(lambda, w, discount, CV_diff1, CV_diff2, Pi_today)

%This m-file solves the static problem of a young agent

global gamma theta rho i_young xi_p Pistar

psi1 = gamma^-1*(1+(theta/(1-theta))^(1/(rho-1))*w^( rho/(rho-1)));
psi2 = gamma^-1*(1+((1-theta)/theta)^(1/(rho-1))*w^(-rho/(rho-1)));

CV = discount*xi_p(i_young)*Pi_today*CV_diff1 + ...
     discount*(1-xi_p(i_young))*(Pi_today+Pistar)*CV_diff2;

b = psi1+psi2+psi1*psi2*(1-CV+lambda);
c = -psi1;

if discount==0
    l = -c/b;
else
    a = CV*psi2*(psi1+psi2+psi1*psi2);
    r = roots([a b c]);
    
    if isreal(r)==false
        error('FOC: not real roots')
    end
    
    l = r(r>0 & r<1);
end

if length(l)==2 % in case two positive roots
    d = zeros(2,1);
    n = zeros(2,1);
    
    for i = 1:2
        d(i) = lambda*l(i)*psi2/(1+CV*l(i)*psi2);
        n(i) = 1-l(i)-d(i);
    end
    
    ifvec = n>0 & n<1 & d>0 & d<1;
    if all(ifvec)
        error('young foc: two positive feasible roots!')
    else
        l = l(ifvec);
        d = d(ifvec);
        n = n(ifvec);
    end 
else
    d = lambda*l*psi2/(1+CV*l*psi2);
    n = 1-l-d;
end

x = w*n/(1+psi1);

