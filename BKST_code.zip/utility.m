function util = utility(c,x,l,d,thelambda)
%This function file computes the utility function

%Global variables:
global b gamma rho theta

%Compute the leisure good:
g = (theta*x^rho + (1-theta)*l^rho)^(1/rho);

%Compute the utility level:
util = log(c) + gamma*log(g) + thelambda*log(d) + b;