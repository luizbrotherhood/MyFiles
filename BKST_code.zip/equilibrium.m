
% This m-file has the main loop that looks for the equilibrium

global x_ub_old

%-------------------------------------------------------------------------%
%                            Initialize arrays                            %
%-------------------------------------------------------------------------%

v_h_terminal = zeros(n_age, 1); % terminal value functions of healthy
v_i_terminal = zeros(n_age, 1); % terminal value functions of infected
v_s_terminal = zeros(n_age, 1); % terminal value functions of symptoms

v_h = zeros(n_age, T); % value function for healthy agents, per age
v_f = zeros(n_age, T); % value function for "fever" agents, per age
v_i = zeros(n_age, T); % value function for infected agents, per age
v_r = zeros(n_age, T); % value function for recovered agents, per age
v_s = zeros(n_age, T); % value function for symptoms agents, per age

v_h_private = zeros(n_age, T); % "private" values don't account for lambda_p
v_f_private = zeros(n_age, T);
v_i_private = zeros(n_age, T);
v_r_private = zeros(n_age, T);
v_s_private = zeros(n_age, T);

v_h_tomorrow = zeros(n_age, 1); % value function tomorrow for healthy agents, per age
v_f_tomorrow = zeros(n_age, 1); % value function tomorrow for "fever" agents, per age
v_i_tomorrow = zeros(n_age, 1);
v_r_tomorrow = zeros(n_age, 1);
v_s_tomorrow = zeros(n_age, 1);

v_h_private_tomorrow = zeros(n_age, 1);
v_f_private_tomorrow = zeros(n_age, 1);
v_i_private_tomorrow = zeros(n_age, 1);
v_r_private_tomorrow = zeros(n_age, 1);
v_s_private_tomorrow = zeros(n_age, 1);

n_h = zeros(n_age, T); % policy function for hours worked for healthy agents, per age
n_f = zeros(n_age, T); % policy function for hours worked for "fever" agents, per age
n_i = zeros(n_age, T); % policy function for hours worked for infected agents, per age
n_r = zeros(n_age, T); % policy function for hours worked for recovered agents, per age

l_h = zeros(n_age, T); % policy function for hours outside for healthy agents, per age
l_f = zeros(n_age, T); % policy function for hours outside for "fever" agents, per age
l_i = zeros(n_age, T); % policy function for hours outside for infected agents, per age
l_r = zeros(n_age, T); % policy function for hours outside for recovered agents, per age

x_h = zeros(n_age, T);
x_f = zeros(n_age, T);
x_i = zeros(n_age, T);
x_r = zeros(n_age, T);

d_h = zeros(n_age, T);
d_f = zeros(n_age, T);
d_i = zeros(n_age, T);
d_r = zeros(n_age, T);

M_h = zeros(n_age, T); % measure of healthy agents
M_f = zeros(n_age, T); % measure of "fever" agents
M_fh = zeros(n_age, T); % measure of healthy "fever" agents
M_fi = zeros(n_age, T); % measure of infected "fever" agents
M_i = zeros(n_age, T); % measure of infected agents
M_s = zeros(n_age, T); % measure of symptoms agents
M_r = zeros(n_age, T); % measure of recovered agents
M_rn = zeros(n_age, T); % measure of recovered agents (non-decreasing due to natural deaths)
M_d = zeros(n_age, T); % measure of deceased agents
M_dn = zeros(n_age, T); % measure of deceased agents
M_t = zeros(n_age, T); % measure of tested agents
M_s_old = zeros(n_age, T); % this is to compare if M_s that agents take as given is close to the real one
N_c_s = zeros(n_age, T); % number of cases (stock)
N_c_f = zeros(n_age, T); % number of cases (flow)

pi_h_vec = zeros(n_age, T-1);
pif_h_vec = zeros(n_age, T-1);
pi_f_vec = zeros(n_age, T-1);
pif_f_vec = zeros(n_age, T-1);

x_h_term = zeros(n_age, 1);
n_h_term = zeros(n_age, 1);
l_h_term = zeros(n_age, 1);
d_h_term = zeros(n_age, 1);

prior_vec = zeros(n_age, T);
delta_vec = zeros(n_age, T); % vector with probability of death
delta_new_vec = zeros(n_age, T);

Delta = zeros(n_age, 1); % survival vector

Pi_hat = zeros(n_age, 2); % related to covid infection
I_new = zeros(T, 1);

% effective discount
Delta(i_young) = survival_young;
Delta(i_old) = survival_old;
beta = time_discount * Delta;

%-------------------------------------------------------------------------%
%               Theoretical bounds for choices of old agents              %
%-------------------------------------------------------------------------%

% finds upper bound of x for old agents
x_ub_old = wbar*gamma/(1+gamma); % this is a rough guess that will always (?) work
x_ub_old = x_ub_old - 0.0001;

fun = @(x) (theta/(1-theta) * (wbar*gamma*x^(rho-1) - (1+gamma)*x^rho))^(1/rho) - 1;
x_ub_old = fzero(fun, [0.0001 x_ub_old]); % this is x such that l_hat(x) = 1;
x_ub_old = x_ub_old - 0.0001;

%-------------------------------------------------------------------------%
%                   Variables in the terminal situation                   %
%-------------------------------------------------------------------------%

% healthy -- terminal value
for i_age = 1:n_age
    if i_age==i_young
        [x,n,l,d] = static_young(lambda_h, w, 0, 0, 0, 0);
        u = utility(w*n-x,x,l,d,lambda_h);
        
        x_h_term(i_age) = x;
        n_h_term(i_age) = n;
        l_h_term(i_age) = l;
        d_h_term(i_age) = d;
    else
        [x,l,d] = static_old(lambda_h,0,0,0,0);
        u = utility(wbar-x,x,l,d,lambda_h);
        
        x_h_term(i_age) = x;
        n_h_term(i_age) = 0;
        l_h_term(i_age) = l;
        d_h_term(i_age) = d;
    end
    
    if flag_fake_young==1 && i_age==i_young
        i_age2 = i_old;
    else
        i_age2 = i_age;
    end
    
    v_h_terminal(i_age) = u/(1-beta(i_age2));
end

% symptoms -- terminal value
for i_age = 1:n_age
    if flag_fake_young==1 && i_age==i_young
        i_age2 = i_old;
    else
        i_age2 = i_age;
    end
    
    Ms = 0; % no one with symptoms in final steady state
    deltat = delta(i_age2)*min(Z/Ms, 1) + delta2(i_age2)*max((Ms-Z)/Ms, 0);

    v_s_terminal(i_age) = beta(i_age2)*phi(i_symptoms, i_age2)*v_h_terminal(i_age) / ...
        (1-beta(i_age2)*(1-phi(i_symptoms, i_age2))*(1-deltat));
end

% infected -- terminal value
for i_age = 1:n_age
    if i_age==i_young
        [x,n,l,d] = static_young(lambda_i, w, 0, 0, 0, 0);
        u = utility(w*n-x,x,l,d,lambda_i);
    else
        [x,l,d] = static_old(lambda_i,0,0,0,0);
        u = utility(wbar-x,x,l,d,lambda_i);
    end
    
    if flag_fake_young==1 && i_age==i_young
        i_age2 = i_old;
    else
        i_age2 = i_age;
    end
    
    v_i_terminal(i_age) = u + beta(i_age2)*phi(i_nosymptoms,i_age2)*v_h_terminal(i_age) + ...
                       beta(i_age2)*(1-phi(i_nosymptoms,i_age2))*alpha(i_age2)*v_s_terminal(i_age);
                            
    v_i_terminal(i_age) = v_i_terminal(i_age)/...
        (1-beta(i_age2)*(1-phi(i_nosymptoms,i_age2))*(1-alpha(i_age2)));
end

%-------------------------------------------------------------------------%
%                         Preparing for main loop                         %
%-------------------------------------------------------------------------%

if flag_Pi==1
    Pi = SP.Pi;
    M_s = SP.M_s;
    I = SP.I;
else
    I = zeros(T, 1); % aggregate infectiousness at each point in time
    I(1:40) = linspace(0, 0.03, 40)';
    I(41:80) = linspace(0.03, 0, 40)';
    Pi = zeros(n_age, T);
    Pi(i_young, :) = 1 - exp(-Pi0 * I);
    Pi(i_old, :) = 1 - exp(-Pi0 * I);
end

% distributions in the first period
ratio = (frac_young * (n_h_term(i_young) + l_h_term(i_young)))/...
    (frac_old * (n_h_term(i_old) + l_h_term(i_old)));
eps_old = initial_sick/(1 + ratio);
eps_young = initial_sick - eps_old;

M_fi(i_young, 1) = eps_young/frac_young;
M_fi(i_old, 1) = eps_old/frac_old;

for i_age = 1:n_age
    pi = (n_h_term(i_age) + l_h_term(i_age)) * Pistar;
    
    M_h(i_age, 1) = (1-pi) * (1-initial_sick);
    M_fh(i_age, 1) = pi * (1-initial_sick);
end

%-------------------------------------------------------------------------%
%                    Distributions in the first period                    %
%-------------------------------------------------------------------------%

%Main loop:
norm = 1;
while norm>toler
    
    % backward induction on value functions
    
    for t=T:-1:1
        if t==T
            for i_age = 1:n_age
                v_h_tomorrow(i_age) = v_h_terminal(i_age);
                v_i_tomorrow(i_age) = v_i_terminal(i_age);
                v_r_tomorrow(i_age) = v_h_terminal(i_age);
                v_f_tomorrow(i_age) = v_h_terminal(i_age);
                v_s_tomorrow(i_age) = v_s_terminal(i_age);
                
                v_h_private_tomorrow(i_age) = v_h_terminal(i_age);
                v_i_private_tomorrow(i_age) = v_i_terminal(i_age);
                v_r_private_tomorrow(i_age) = v_h_terminal(i_age);
                v_f_private_tomorrow(i_age) = v_h_terminal(i_age);
                v_s_private_tomorrow(i_age) = v_s_terminal(i_age);
            end
        else
            for i_age = 1:n_age
                v_h_tomorrow(i_age) = v_h(i_age, t+1);
                v_i_tomorrow(i_age) = v_i(i_age, t+1);
                v_r_tomorrow(i_age) = v_r(i_age, t+1);
                v_f_tomorrow(i_age) = v_f(i_age, t+1);
                v_s_tomorrow(i_age) = v_s(i_age, t+1);
                
                v_h_private_tomorrow(i_age) = v_h_private(i_age, t+1);
                v_i_private_tomorrow(i_age) = v_i_private(i_age, t+1);
                v_r_private_tomorrow(i_age) = v_r_private(i_age, t+1);
                v_f_private_tomorrow(i_age) = v_f_private(i_age, t+1);
                v_s_private_tomorrow(i_age) = v_s_private(i_age, t+1);
            end
        end
        if t==1
%             Pi_yesterday = 0; OLD VERSION
            Pi_yesterday2 = [0, 0];
        else
%             Pi_yesterday = Pi(t-1); OLD VERSION
            Pi_yesterday2 = [Pi(i_young, t-1), Pi(i_old, t-1)];
        end
        
        % value functions
        for i_age = 1:n_age
            
            % if we want young agents to use some variables of the old
            if flag_fake_young==1 && i_age==i_young
                i_age2 = i_old;
            else
                i_age2 = i_age;
            end
            
            % resistant
            if i_age==i_young
                if flag_epidemiological==1
                    x = x_h_term(i_age);
                    n = n_h_term(i_age);
                    l = l_h_term(i_age);
                    d = d_h_term(i_age);
                else
                    [x,n,l,d] = static_young(lambda_h + lambda_p_h(i_age,t), w, 0, 0, 0, 0);
                end
                
                u = utility(w*n-x,x,l,d,lambda_h + lambda_p_h(i_age,t));
                u_private = utility(w*n-x,x,l,d,lambda_h);
                
                x_r(i_age,t) = x;
                n_r(i_age,t) = n;
                l_r(i_age,t) = l;
                d_r(i_age,t) = d;
            else
                if flag_epidemiological==1
                    x = x_h_term(i_age);
                    n = n_h_term(i_age);
                    l = l_h_term(i_age);
                    d = d_h_term(i_age);
                else
                    [x,l,d] = static_old(lambda_h + lambda_p_h(i_age,t), 0, 0, 0, 0);
                end
                
                u = utility(wbar-x,x,l,d,lambda_h + lambda_p_h(i_age,t));
                u_private = utility(wbar-x,x,l,d,lambda_h);

                n_r(i_age,t) = 0;
                x_r(i_age,t) = x;
                l_r(i_age,t) = l;
                d_r(i_age,t) = d;
            end

            v_r(i_age,t) = u + beta(i_age2)*v_r_tomorrow(i_age);
            
            v_r_private(i_age,t) = u_private + beta(i_age2)*v_r_private_tomorrow(i_age);
            
            if any([x, n, l, d]<0)
                error('negative choices')
            end

            % symptoms
            U = frac_young * M_s(i_young, t) * (1-phi(i_symptoms, i_age)) + ...
                frac_old * M_s(i_old, t) * (1-phi(i_symptoms, i_age));
            deltat = delta(i_age2) * min(Z/U, 1) + delta2(i_age2) * max((U-Z)/U, 0);
            
            delta_new_vec(i_age, t) = deltat;
            weight_new = 0.25;
            delta_vec(i_age, t) = weight_new * deltat + (1-weight_new) * delta_vec(i_age, t);
            
            v_s(i_age, t) = beta(i_age2)*(phi(i_symptoms, i_age2)*v_r_tomorrow(i_age) + ...
                (1-phi(i_symptoms, i_age2))*(1-deltat)*v_s_tomorrow(i_age));

            v_s_private(i_age, t) = beta(i_age2)*(phi(i_symptoms, i_age2)*v_r_private_tomorrow(i_age) + ...
                (1-phi(i_symptoms, i_age2))*(1-deltat)*v_s_private_tomorrow(i_age));
            
            % infected
            if i_age==i_young
                if flag_epidemiological==1
                    x = x_h_term(i_age);
                    n = n_h_term(i_age);
                    l = l_h_term(i_age);
                    d = d_h_term(i_age);
                else
                    [x,n,l,d] = static_young(lambda_i + lambda_p_i(i_age,t), w, 0, 0, 0, 0);
                end
                
                x_i(i_age,t) = x;
                n_i(i_age,t) = n;
                l_i(i_age,t) = l;
                d_i(i_age,t) = d;
                
                u = utility(w*n-x,x,l,d,lambda_i + lambda_p_i(i_age,t));
                u_private = utility(w*n-x,x,l,d,lambda_i);
            else
                if flag_epidemiological==1
                    x = x_h_term(i_age);
                    n = n_h_term(i_age);
                    l = l_h_term(i_age);
                    d = d_h_term(i_age);
                else
                    [x,l,d] = static_old(lambda_i + lambda_p_i(i_age,t), 0, 0, 0, 0);
                end
                
                n_i(i_age,t) = 0;
                x_i(i_age,t) = x;
                l_i(i_age,t) = l;
                d_i(i_age,t) = d;
                
                u = utility(wbar-x,x,l,d,lambda_i + lambda_p_i(i_age,t));
                u_private = utility(wbar-x,x,l,d,lambda_i);
            end
            
            v_i(i_age,t) = u + beta(i_age2)*phi(i_nosymptoms,i_age2)*v_r_tomorrow(i_age) + ...
                            beta(i_age2)*(1-phi(i_nosymptoms,i_age2))*alpha(i_age2)*v_s_tomorrow(i_age) + ...
                            beta(i_age2)*(1-phi(i_nosymptoms,i_age2))*(1-alpha(i_age2))*v_i_tomorrow(i_age);

            v_i_private(i_age,t) = u_private + beta(i_age2)*phi(i_nosymptoms,i_age2)*v_r_private_tomorrow(i_age) + ...
                            beta(i_age2)*(1-phi(i_nosymptoms,i_age2))*alpha(i_age2)*v_s_private_tomorrow(i_age) + ...
                            beta(i_age2)*(1-phi(i_nosymptoms,i_age2))*(1-alpha(i_age2))*v_i_private_tomorrow(i_age);
            
            if any([x,n,l,d]<0)
                error('negative choices')
            end
            
            % healthy
            CV_diff1 = v_i_tomorrow(i_age) - v_h_tomorrow(i_age);
            CV_diff2 = v_f_tomorrow(i_age) - v_h_tomorrow(i_age);

            if i_age==i_young
                if flag_epidemiological==1
                    x = x_h_term(i_age);
                    n = n_h_term(i_age);
                    l = l_h_term(i_age);
                    d = d_h_term(i_age);
                else
%                     [x,n,l,d] = static_young(lambda_h + lambda_p_h(i_age,t), ...
%                             w, beta(i_age2), CV_diff1, CV_diff2, Pi(t)); % OLD VERSION
                    [x,n,l,d] = static_young(lambda_h + lambda_p_h(i_age,t), ...
                            w, beta(i_age2), CV_diff1, CV_diff2, Pi(i_age, t));
                end
                
%                 pi = (n+l)*Pi(t); % OLD VERSION
                pi = (n+l)*Pi(i_age, t);
                pif = pi + (n+l)*Pistar;
                u = utility(w*n-x,x,l,d,lambda_h + lambda_p_h(i_age,t));
                u_private = utility(w*n-x,x,l,d,lambda_h);
                
                x_h(i_age, t) = x;
                n_h(i_age, t) = n;
                l_h(i_age, t) = l;
                d_h(i_age, t) = d;
            else
                if flag_epidemiological==1
                    x = x_h_term(i_age);
                    n = n_h_term(i_age);
                    l = l_h_term(i_age);
                    d = d_h_term(i_age);
                else
%                     [x,l,d] = static_old(lambda_h + lambda_p_h(i_age,t), ...
%                             beta(i_age), CV_diff1, CV_diff2, Pi(t)); % OLD VERSION
                    [x,l,d] = static_old(lambda_h + lambda_p_h(i_age,t), ...
                            beta(i_age), CV_diff1, CV_diff2, Pi(i_age, t));
                end
                
%                 pi = l*Pi(t); % OLD VERSION
                pi = l*Pi(i_age, t);
                pif = pi + l*Pistar;
                u = utility(wbar-x,x,l,d,lambda_h + lambda_p_h(i_age,t));
                u_private = utility(wbar-x,x,l,d,lambda_h);

                x_h(i_age, t) = x;
                n_h(i_age, t) = 0;
                l_h(i_age, t) = l;
                d_h(i_age, t) = d;
            end
            
            if any([x,n,l,d]<0)
                error('negative choices')
            end
            
            CV1 = pi*v_i_tomorrow(i_age) + (1-pi)*v_h_tomorrow(i_age);
            CV2 = pif*v_f_tomorrow(i_age) + (1-pif)*v_h_tomorrow(i_age);
            v_h(i_age, t) = u + beta(i_age2)*xi_p(i_age)*CV1 + beta(i_age2)*(1-xi_p(i_age))*CV2;
            
            CV1 = pi*v_i_private_tomorrow(i_age) + (1-pi)*v_h_private_tomorrow(i_age);
            CV2 = pif*v_f_private_tomorrow(i_age) + (1-pif)*v_h_private_tomorrow(i_age);
            v_h_private(i_age, t) = u_private + beta(i_age2)*xi_p(i_age)*CV1 + beta(i_age2)*(1-xi_p(i_age))*CV2;
            
            % "fever"
%             prior = Pistar/(Pi_yesterday+Pistar); % OLD VERSION
            prior = Pistar/(Pi_yesterday2(i_age)+Pistar);
            discount = beta(i_age2)*prior;
            CV_diff1 = v_i_tomorrow(i_age) - v_h_tomorrow(i_age);
            CV_diff2 = v_f_tomorrow(i_age) - v_h_tomorrow(i_age);
            lambda = (1-prior)*lambda_i ...
                       + prior*lambda_h + lambda_p_f(i_age, t);
            lambda_private = (1-prior)*lambda_i + prior*lambda_h;
            
            if i_age==i_young
                if flag_epidemiological==1
                    x = x_h_term(i_age);
                    n = n_h_term(i_age);
                    l = l_h_term(i_age);
                    d = d_h_term(i_age);
                else
%                     [x,n,l,d] = static_young(lambda, ...
%                             w, discount, CV_diff1, CV_diff2, Pi(t)); % OLD VERSION
                    [x,n,l,d] = static_young(lambda, ...
                            w, discount, CV_diff1, CV_diff2, Pi(i_age, t));
                end
                
%                 pi = (n+l)*Pi(t); % OLD VERSION
                pi = (n+l)*Pi(i_age, t);
                pif = pi + (n+l)*Pistar;
                u = utility(w*n-x,x,l,d,lambda);
                u_private = utility(w*n-x,x,l,d,lambda_private);
                
                x_f(i_age, t) = x;
                n_f(i_age, t) = n;
                l_f(i_age, t) = l;
                d_f(i_age, t) = d;
            else
                if flag_epidemiological==1
                    x = x_h_term(i_age);
                    n = n_h_term(i_age);
                    l = l_h_term(i_age);
                    d = d_h_term(i_age);
                else
%                     [x,l,d] = static_old(lambda, discount, CV_diff1, CV_diff2, Pi(t)); % OLD VERSION
                    [x,l,d] = static_old(lambda, discount, CV_diff1, CV_diff2, Pi(i_age, t));
                end
                
%                 pi = l*Pi(t); % OLD VERSION
                pi = l*Pi(i_age, t);
                pif = pi + l*Pistar;
                u = utility(wbar-x,x,l,d,lambda);
                u_private = utility(wbar-x,x,l,d,lambda_private);
                
                x_f(i_age, t) = x;
                n_f(i_age, t) = 0;
                l_f(i_age, t) = l;
                d_f(i_age, t) = d;
            end
            
            if any([x,n,l,d]<0)
                error('negative choices')
            end
            
            CV1 = phi(i_nosymptoms,i_age2)*v_r_tomorrow(i_age) ...
                + (1-phi(i_nosymptoms,i_age2))*alpha(i_age2)*v_s_tomorrow(i_age) ...
                + (1-phi(i_nosymptoms,i_age2))*(1-alpha(i_age2))*v_i_tomorrow(i_age);
            
            CV2 = xi_p(i_age)*(pi*v_i_tomorrow(i_age)+(1-pi)*v_h_tomorrow(i_age)) ...
                + (1-xi_p(i_age))*(pif*v_f_tomorrow(i_age)+(1-pif)*v_h_tomorrow(i_age));
            
            v_f(i_age, t) = u + beta(i_age2)*(1-prior)*CV1 + beta(i_age2)*prior*CV2;
            
            CV1 = phi(i_nosymptoms,i_age2)*v_r_private_tomorrow(i_age) ...
                + (1-phi(i_nosymptoms,i_age2))*alpha(i_age2)*v_s_private_tomorrow(i_age) ...
                + (1-phi(i_nosymptoms,i_age2))*(1-alpha(i_age2))*v_i_private_tomorrow(i_age);
            
            CV2 = xi_p(i_age)*(pi*v_i_private_tomorrow(i_age)+(1-pi)*v_h_private_tomorrow(i_age)) ...
                + (1-xi_p(i_age))*(pif*v_f_private_tomorrow(i_age)+(1-pif)*v_h_private_tomorrow(i_age));
            
            v_f_private(i_age, t) = u_private + beta(i_age2)*(1-prior)*CV1 + beta(i_age2)*prior*CV2;
            
            prior_vec(i_age, t) = prior;
        end
    end
    
    % forward induction on distributions
    M_s_old = M_s;
    
    for t = 1:T-1
        for i_age = 1:n_age
            % pis
            if flag_epidemiological==1
                pi_h = (n_h_term(i_age) + l_h_term(i_age))*Pi(i_age, t);
                pif_h = pi_h + (n_h_term(i_age) + l_h_term(i_age))*Pistar;

                pi_f = (n_h_term(i_age) + l_h_term(i_age))*Pi(i_age, t);
                pif_f = pi_f + (n_h_term(i_age) + l_h_term(i_age))*Pistar;
            else
                pi_h = (n_h(i_age, t) + l_h(i_age, t))*Pi(i_age, t);
                pif_h = pi_h + (n_h(i_age, t) + l_h(i_age, t))*Pistar;

                pi_f = (n_f(i_age, t) + l_f(i_age, t))*Pi(i_age, t);
                pif_f = pi_f + (n_f(i_age, t) + l_f(i_age, t))*Pistar;
            end

            % stores probabilities in a vector to plot later
            pi_h_vec(i_age, t) = pi_h;
            pif_h_vec(i_age, t) = pif_h;
            pi_f_vec(i_age, t) = pi_f;
            pif_f_vec(i_age, t) = pif_f;

            % probability to die if develops symptoms
            U = frac_young * M_s(i_young, t) * (1-phi(i_symptoms, i_age)) + ...
                frac_old * M_s(i_old, t) * (1-phi(i_symptoms, i_age));
            deltat = delta(i_age) * min(Z/U, 1) + delta2(i_age) * max((U-Z)/U, 0);

            % masses
            M_h(i_age, t+1) = M_h(i_age, t)*(1-xi_p(i_age))*(1-pif_h) ...
                + M_h(i_age, t)*xi_p(i_age)*(1-pi_h) ...
                + M_fh(i_age, t)*xi_p(i_age)*(1-pi_f) ... 
                + M_fh(i_age, t)*(1-xi_p(i_age))*(1-pif_f);
            M_h(i_age, t+1) = M_h(i_age, t+1) * Delta(i_age);

            M_fh(i_age, t+1) = M_h(i_age, t)*(1-xi_p(i_age))*pif_h*(Pistar/(Pi(i_age, t)+Pistar)) ...
                + M_fh(i_age, t)*(1-xi_p(i_age))*pif_f*(Pistar/(Pi(i_age, t)+Pistar));
            M_fh(i_age, t+1) = M_fh(i_age, t+1) * Delta(i_age);

            M_fi(i_age, t+1) = M_h(i_age, t)*(1-xi_p(i_age))*pif_h*(Pi(i_age, t)/(Pi(i_age, t)+Pistar)) ...
                + M_fh(i_age, t)*(1-xi_p(i_age))*pif_f*(Pi(i_age, t)/(Pi(i_age, t)+Pistar));
            M_fi(i_age, t+1) = M_fi(i_age, t+1) * Delta(i_age);

            M_i(i_age, t+1) = M_h(i_age, t)*xi_p(i_age)*pi_h ...
                + M_fh(i_age, t)*xi_p(i_age)*pi_f ...
                + (M_fi(i_age, t) + M_i(i_age, t))*(1-phi(i_nosymptoms,i_age))*(1-alpha(i_age));
            M_i(i_age, t+1) = M_i(i_age, t+1) * Delta(i_age);
            
            M_s(i_age, t+1) = (M_fi(i_age, t) + M_i(i_age, t))*(1-phi(i_nosymptoms,i_age))*alpha(i_age) ...
                + M_s(i_age, t)*(1-deltat)*(1-phi(i_symptoms, i_age));
            M_s(i_age, t+1) = M_s(i_age, t+1) * Delta(i_age);

            M_r(i_age, t+1) = (M_fi(i_age, t) + M_i(i_age, t))*phi(i_nosymptoms, i_age) ...
                + M_s(i_age, t)*phi(i_symptoms, i_age) ...
                + M_r(i_age, t);
            M_r(i_age, t+1) = M_r(i_age, t+1) * Delta(i_age);
        end
    end
    
    % computes new Pi_hat
    if flag_Pi==1
        Pi_new = SP.Pi;
        I_new = SP.I;
    else
        Pi_hat(:, :) = 0;

        for t = 1:T
            
            if t >= t_vaccine
                
                Pi_hat(:, t) = 0;
                
            else
                
                for i_age = 1:n_age
                    % 1-zeta term
                    sum1 = 0;

                    for i_age2 = 1:n_age
                        n_plus_l_f = n_f(i_age2, t) + l_f(i_age2, t);
                        n_plus_l_i = n_i(i_age2, t) + l_i(i_age2, t);

                        if i_age2==i_young
                            frac = frac_young;
                        else
                            frac = frac_old;
                        end

                        sum1 = sum1 + frac*(n_plus_l_f*M_fi(i_age2, t) ...
                                            + n_plus_l_i*M_i(i_age2, t) ...
                                            + n_plus_l_s*M_s(i_age2, t));
                    end

                    I_new(t) = sum1;

                    % zeta term
                    n_plus_l_f = n_f(i_age, t) + l_f(i_age, t);
                    n_plus_l_i = n_i(i_age, t) + l_i(i_age, t);

                    if i_age==i_young
                        frac = frac_young;
                    else
                        frac = frac_old;
                    end

                    sum2 = frac*(n_plus_l_f*M_fi(i_age, t) ...
                               + n_plus_l_i*M_i(i_age, t) ...
                               + n_plus_l_s*M_s(i_age, t));

                    % computes new Pi_hat
                    Pi_hat(i_age, t) = (1-zeta)*Pi0*sum1 + ...
                        (zeta*Pi0/vartheta(i_age))*sum2;
                end
                
            end
        end
        
        % new Pi
        Pi_new = 1 - exp(-Pi_hat);
    end
    % cezar: matlatb servidor (Mail antero)
    % checks for convergence - update norm
    X_new = [Pi_new(:); M_s(:); delta_new_vec(:)];
    X_old = [Pi(:); M_s_old(:); delta_vec(:)];
    
    norm = max(abs(X_new - X_old));
    
    % updates Pi
    weigth_new = 0.5;
    Pi = weigth_new * Pi_new + (1-weigth_new) * Pi;
    I = I_new;
    
%     fprintf('norm: %.8e\n', norm)
end

fprintf('max(Pi(:, T)) = %.8e\n', max(Pi(:, T)))

% computes some distribution variables that were not needed in the main
% loop

% mass of agents with fever (cold or covid)
M_f = M_fh + M_fi;

M_i_all = M_i + M_fi + M_s;

for t = 1:T-1
    for i_age = 1:n_age
        % deltat
        U = frac_young * M_s(i_young, t) * (1-phi(i_symptoms, i_age)) + ...
            frac_old * M_s(i_old, t) * (1-phi(i_symptoms, i_age));
        deltat = delta(i_age) * min(Z/U, 1) + delta2(i_age) * max((U-Z)/U, 0);
        
        % number of tests per period
        M_t(i_age, t+1) = M_h(i_age, t) * Delta(i_age) * pif_h_vec(i_age, t) * xi_p(i_age) + ...
                         M_fh(i_age, t) * Delta(i_age) * pif_f_vec(i_age, t) * xi_p(i_age);
        
        % cumulative mass of recovered agents (doesn't takes into account
        % natural deaths)
        M_rn(i_age, t+1) = (M_fi(i_age, t) + M_i(i_age, t)) * phi(i_nosymptoms, i_age) ...
            + M_s(i_age, t) * phi(i_symptoms, i_age);
        M_rn(i_age, t+1) = M_rn(i_age, t+1) * Delta(i_age);
        M_rn(i_age, t+1) = M_rn(i_age, t+1) + M_rn(i_age, t);
        
        % mass of dead agents (only covid deaths)
        M_d(i_age, t+1) = M_d(i_age, t) ...
            + M_s(i_age, t) * Delta(i_age) * deltat * (1-phi(i_symptoms, i_age));
        
        % mass of deceased agents (only natural deaths)
        M_dn(i_age, t+1) = M_dn(i_age, t) ...
            + M_h(i_age, t) * (1-Delta(i_age)) ...
            + M_f(i_age, t) * (1-Delta(i_age)) ...
            + M_i(i_age, t) * (1-Delta(i_age)) ...
            + M_r(i_age, t) * (1-Delta(i_age)) ...
            + M_s(i_age, t) * (1-Delta(i_age));
        
        % mass of covid cases (flux)
        N_c_f(i_age, t+1) = M_h(i_age, t) * pi_h_vec(i_age, t) + M_fh(i_age, t) * pi_f_vec(i_age, t);
        N_c_f(i_age, t+1) = N_c_f(i_age, t+1) * Delta(i_age);

        % mass of covid cases (stock)
        N_c_s(i_age, t+1) = N_c_f(i_age, t+1) + N_c_s(i_age, t);
    end
end

% checks if distributions sum to one (ok!)
% M_h + M_fh + M_fi + M_i + M_s + M_r + M_d + M_dn

% gdp
gdp = w * (n_h(i_young,:) .* M_h(i_young,:) ...
         + n_f(i_young,:) .* M_f(i_young,:) ...
         + n_i(i_young,:) .* M_i(i_young,:) ...
         + n_r(i_young,:) .* M_r(i_young,:));

% gdp per capita
gdp_pc = gdp ./ (1-M_d(i_young,:)-M_dn(i_young,:));

% consumption
c_h = zeros(n_age,T);
c_f = zeros(n_age,T);
c_i = zeros(n_age,T);
c_r = zeros(n_age,T);

c_h(i_young,:) = w*n_h(i_young,:)-x_h(i_young,:);
c_f(i_young,:) = w*n_f(i_young,:)-x_f(i_young,:);
c_i(i_young,:) = w*n_i(i_young,:)-x_i(i_young,:);
c_r(i_young,:) = w*n_r(i_young,:)-x_r(i_young,:);

c_h(i_old,:) = wbar-x_h(i_old,:);
c_f(i_old,:) = wbar-x_f(i_old,:);
c_i(i_old,:) = wbar-x_i(i_old,:);
c_r(i_old,:) = wbar-x_r(i_old,:);

% time to peak
[~, t_peak_I] = max(I);
  
  
  
  
  
  
  
  
  
  
  
