

close all

color_y = [0, 0.4470, 0.7410]; % blue
color_o = [0.8500, 0.3250, 0.0980]; % red

% color_y = [35/250,55/250,59/250]; % metropolis beamer theme
% color_o = [235/250,129/250,27/250]; % metropolis beamer theme

colors = {color_y; color_o; color_y; color_o};
linestyles = {"-", "-", "--", "--"};

fig_pos1 = [374.33, -1.66, 1280, 871.33]; % bigger figure
fig_pos2 = [374.33, -1.66, 1012, 871.33]; % smaller figure

t0 = 2; % first t to plot
t1 = T; % last t to plot

%%

% 0: for slides
%%%%%%%%%%%%%%%

s = ["M_d", "M_i", "M_fi", "gdp", "d_h", "prior_vec"];
t = ["$M_d$", "$M_{i}$", "$M_{fi}$", "GDP", "$d_h$", "Belief (healthy)"];

figure
set(gcf, 'Position', fig_pos1);

for i = 1:length(s)
    subplot(3,2,i)
    hold on
    
    X = cell(4, 1);
    
    eval(strcat("Y = ", s(i), ";"));
    t1m = min(t1, length(Y));
    
    if exist('SF','var')==1
        eval(strcat("Y0 = SF.", s(i), ";"));
        
        if size(Y, 1)==2
            if flag_epidemiological==1
                X{1} = Y0(1, t0:t1m);
                X{2} = Y0(2, t0:t1m);
                X{3} = Y(1, t0:t1m);
                X{4} = Y(2, t0:t1m);
            else
                X{1} = Y(1, t0:t1m);
                X{2} = Y(2, t0:t1m);
                X{3} = Y0(1, t0:t1m);
                X{4} = Y0(2, t0:t1m);
            end
        else
            if flag_epidemiological==1
                X{1} = Y0(t0:t1m);
                X{3} = Y(t0:t1m);
            else
                X{1} = Y(t0:t1m);
                X{3} = Y0(t0:t1m);
            end
        end
    else
        if size(Y, 1)==2
            X{1} = Y(1, t0:t1m);
            X{2} = Y(2, t0:t1m);
        else
            X{1} = Y(t0:t1m);
        end
        
    end
    
    for j = 1:4
        plot(X{j}', linestyles{j}, 'color', colors{j}, 'LineWidth', 2)
    end
    
    title(t(i),'interpreter','latex','FontSize',14)
    
    grid on
    if i==1
        if flag_epidemiological==1
            leg = {'Young', 'Old', 'Young (epidem.)', 'Old (epidem.)'};
        else
            if exist('SF','var')==1
                leg = {'Young', 'Old', 'Young (benchmark)', 'Old (benchmark)'};
            else
                leg = {'Young', 'Old'};
            end
        end
        
        legend(leg, ...
            'Orientation', 'horizontal', ...
            'Position', [0.5 0.9875 0 0], ... % [x y width height]
            'FontSize', 10)
    end
end

if exist('filename_suffix_slides','var')==1 && filename_suffix_slides~=""
    filename = strcat("results/figures/fig", filename_suffix_slides);
    saveas(gcf, filename, 'epsc')
end

%%

% 1: masses
%%%%%%%%%%%

s = ["M_h", "M_fh", "M_fi", "M_f", "M_i", "M_s", "M_r", "M_d", "Pi"];
t = ["$M_h$", "$M_{fh}$", "$M_{fi}$", "$M_f$", "$M_i$", "$M_s$", "$M_r$", "$M_d$", "$\Pi$"];

figure
set(gcf, 'Position', fig_pos1);

for i = 1:length(s)
    subplot(3,3,i)
    hold on
    
    X = cell(4, 1);
    
    eval(strcat("Y = ", s(i), ";"));
    t1m = min(t1, length(Y));
    
    if exist('SF','var')==1
        eval(strcat("Y0 = SF.", s(i), ";"));
        
        if size(Y, 1)==2
            if flag_epidemiological==1
                X{1} = Y0(1, t0:t1m);
                X{2} = Y0(2, t0:t1m);
                X{3} = Y(1, t0:t1m);
                X{4} = Y(2, t0:t1m);
            else
                X{1} = Y(1, t0:t1m);
                X{2} = Y(2, t0:t1m);
                X{3} = Y0(1, t0:t1m);
                X{4} = Y0(2, t0:t1m);
            end
        else
            if flag_epidemiological==1
                X{1} = Y0(t0:t1m);
                X{3} = Y(t0:t1m);
            else
                X{1} = Y(t0:t1m);
                X{3} = Y0(t0:t1m);
            end
        end
    else
        if size(Y, 1)==2
            X{1} = Y(1, t0:t1m);
            X{2} = Y(2, t0:t1m);
        else
            X{1} = Y(t0:t1m);
        end
        
    end
    
    for j = 1:4
        plot(X{j}', linestyles{j}, 'color', colors{j}, 'LineWidth', 2)
    end
    
    title(t(i),'interpreter','latex','FontSize',14)
    
    grid on
    if i==1
        if flag_epidemiological==1
            leg = {'Young', 'Old', 'Young (epidem.)', 'Old (epidem.)'};
        else
            if exist('SF','var')==1
                leg = {'Young', 'Old', 'Young (benchmark)', 'Old (benchmark)'};
            else
                leg = {'Young', 'Old'};
            end
        end
        
        legend(leg, ...
            'Orientation', 'horizontal', ...
            'Position', [0.5 0.9875 0 0], ... % [x y width height]
            'FontSize', 10)
    end
end

if exist('filename_fig_suffix', 'var')==1 && filename_fig_suffix~=""
    filename = strcat("results/figures/masses", filename_fig_suffix);
    saveas(gcf, filename, 'epsc')
end

%%
% 2: choices and value by state
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% healthy
s = ["c_h", "n_h", "l_h", "x_h", "d_h", "v_h"];
t = ["$c_h$", "$n_h$", "$l_h$", "$x_h$", "$d_h$", "$v_h$"];

figure
set(gcf, 'Position', fig_pos2);

for i = 1:length(s)
    subplot(3,2,i)
    hold on
    
    X = cell(4, 1);
    
    eval(strcat("Y = ", s(i), ";"));
    t1m = min(t1, length(Y));
    
    if exist('SF','var')==1
        eval(strcat("Y0 = SF.", s(i), ";"));
        
        if size(Y, 1)==2
            if flag_epidemiological==1
                X{1} = Y0(1, t0:t1m);
                X{2} = Y0(2, t0:t1m);
                X{3} = Y(1, t0:t1m);
                X{4} = Y(2, t0:t1m);
            else
                X{1} = Y(1, t0:t1m);
                X{2} = Y(2, t0:t1m);
                X{3} = Y0(1, t0:t1m);
                X{4} = Y0(2, t0:t1m);
            end
        else
            if flag_epidemiological==1
                X{1} = Y0(t0:t1m);
                X{3} = Y(t0:t1m);
            else
                X{1} = Y(t0:t1m);
                X{3} = Y0(t0:t1m);
            end
        end
    else
        if size(Y, 1)==2
            X{1} = Y(1, t0:t1m);
            X{2} = Y(2, t0:t1m);
        else
            X{1} = Y(t0:t1m);
        end
        
    end
    
    for j = 1:4
        plot(X{j}', linestyles{j}, 'color', colors{j}, 'LineWidth', 2)
    end
    
    title(t(i),'interpreter','latex','FontSize',14)
    
    grid on
    if i==1
        if flag_epidemiological==1
            leg = {'Young', 'Old', 'Young (epidem.)', 'Old (epidem.)'};
        else
            if exist('SF','var')==1
                leg = {'Young', 'Old', 'Young (benchmark)', 'Old (benchmark)'};
            else
                leg = {'Young', 'Old'};
            end
        end
        
        legend(leg, ...
            'Orientation', 'horizontal', ...
            'Position', [0.5 0.9875 0 0], ... % [x y width height]
            'FontSize', 10)
    end
end

if exist('filename_fig_suffix', 'var')==1 && filename_fig_suffix~=""
    filename = strcat("results/figures/choices_h" ,filename_fig_suffix);
    saveas(gcf, filename, 'epsc')
end

%%
% fever
s = ["c_f", "n_f", "l_f", "x_f", "d_f", "v_f"];
t = ["$c_f$", "$n_f$", "$l_f$", "$x_f$", "$d_f$", "$v_f$"];

figure
set(gcf, 'Position', fig_pos2);

for i = 1:length(s)
    subplot(3,2,i)
    hold on
    
    X = cell(4, 1);
    
    eval(strcat("Y = ", s(i), ";"));
    t1m = min(t1, length(Y));
    
    if exist('SF','var')==1
        eval(strcat("Y0 = SF.", s(i), ";"));
        
        if size(Y, 1)==2
            if flag_epidemiological==1
                X{1} = Y0(1, t0:t1m);
                X{2} = Y0(2, t0:t1m);
                X{3} = Y(1, t0:t1m);
                X{4} = Y(2, t0:t1m);
            else
                X{1} = Y(1, t0:t1m);
                X{2} = Y(2, t0:t1m);
                X{3} = Y0(1, t0:t1m);
                X{4} = Y0(2, t0:t1m);
            end
        else
            if flag_epidemiological==1
                X{1} = Y0(t0:t1m);
                X{3} = Y(t0:t1m);
            else
                X{1} = Y(t0:t1m);
                X{3} = Y0(t0:t1m);
            end
        end
    else
        if size(Y, 1)==2
            X{1} = Y(1, t0:t1m);
            X{2} = Y(2, t0:t1m);
        else
            X{1} = Y(t0:t1m);
        end
        
    end
    
    for j = 1:4
        plot(X{j}', linestyles{j}, 'color', colors{j}, 'LineWidth', 2)
    end
    
    title(t(i),'interpreter','latex','FontSize',14)
    
    grid on
    if i==1
        if flag_epidemiological==1
            leg = {'Young', 'Old', 'Young (epidem.)', 'Old (epidem.)'};
        else
            if exist('SF','var')==1
                leg = {'Young', 'Old', 'Young (benchmark)', 'Old (benchmark)'};
            else
                leg = {'Young', 'Old'};
            end
        end
        
        legend(leg, ...
            'Orientation', 'horizontal', ...
            'Position', [0.5 0.9875 0 0], ... % [x y width height]
            'FontSize', 10)
    end
end


if exist('filename_fig_suffix', 'var')==1 && filename_fig_suffix~=""
    filename = strcat("results/figures/choices_f" ,filename_fig_suffix);
    saveas(gcf, filename, 'epsc')
end

%%
% infected
s = ["c_i", "n_i", "l_i", "x_i", "d_i", "v_i"];
t = ["$c_i$", "$n_i$", "$l_i$", "$x_i$", "$d_i$", "$v_i$"];

figure
set(gcf, 'Position', fig_pos2);

for i = 1:length(s)
    subplot(3,2,i)
    hold on
    
    X = cell(4, 1);
    
    eval(strcat("Y = ", s(i), ";"));
    t1m = min(t1, length(Y));
    
    if exist('SF','var')==1
        eval(strcat("Y0 = SF.", s(i), ";"));
        
        if size(Y, 1)==2
            if flag_epidemiological==1
                X{1} = Y0(1, t0:t1m);
                X{2} = Y0(2, t0:t1m);
                X{3} = Y(1, t0:t1m);
                X{4} = Y(2, t0:t1m);
            else
                X{1} = Y(1, t0:t1m);
                X{2} = Y(2, t0:t1m);
                X{3} = Y0(1, t0:t1m);
                X{4} = Y0(2, t0:t1m);
            end
        else
            if flag_epidemiological==1
                X{1} = Y0(t0:t1m);
                X{3} = Y(t0:t1m);
            else
                X{1} = Y(t0:t1m);
                X{3} = Y0(t0:t1m);
            end
        end
    else
        if size(Y, 1)==2
            X{1} = Y(1, t0:t1m);
            X{2} = Y(2, t0:t1m);
        else
            X{1} = Y(t0:t1m);
        end
        
    end
    
    for j = 1:4
        plot(X{j}', linestyles{j}, 'color', colors{j}, 'LineWidth', 2)
    end
    
    title(t(i),'interpreter','latex','FontSize',14)
    
    grid on
    if i==1
        if flag_epidemiological==1
            leg = {'Young', 'Old', 'Young (epidem.)', 'Old (epidem.)'};
        else
            if exist('SF','var')==1
                leg = {'Young', 'Old', 'Young (benchmark)', 'Old (benchmark)'};
            else
                leg = {'Young', 'Old'};
            end
        end
        
        legend(leg, ...
            'Orientation', 'horizontal', ...
            'Position', [0.5 0.9875 0 0], ... % [x y width height]
            'FontSize', 10)
    end
end

if exist('filename_fig_suffix', 'var')==1 && filename_fig_suffix~=""
    filename = strcat("results/figures/choices_i" ,filename_fig_suffix);
    saveas(gcf, filename, 'epsc')
end

%%
% resistant
s = ["c_r", "n_r", "l_r", "x_r", "d_r", "v_r"];
t = ["$c_r$", "$n_r$", "$l_r$", "$x_r$", "$d_r$", "$v_r$"];

figure
set(gcf, 'Position', fig_pos2);

for i = 1:length(s)
    subplot(3,2,i)
    hold on
    
    X = cell(4, 1);
    
    eval(strcat("Y = ", s(i), ";"));
    t1m = min(t1, length(Y));
    
    if exist('SF','var')==1
        eval(strcat("Y0 = SF.", s(i), ";"));
        
        if size(Y, 1)==2
            if flag_epidemiological==1
                X{1} = Y0(1, t0:t1m);
                X{2} = Y0(2, t0:t1m);
                X{3} = Y(1, t0:t1m);
                X{4} = Y(2, t0:t1m);
            else
                X{1} = Y(1, t0:t1m);
                X{2} = Y(2, t0:t1m);
                X{3} = Y0(1, t0:t1m);
                X{4} = Y0(2, t0:t1m);
            end
        else
            if flag_epidemiological==1
                X{1} = Y0(t0:t1m);
                X{3} = Y(t0:t1m);
            else
                X{1} = Y(t0:t1m);
                X{3} = Y0(t0:t1m);
            end
        end
    else
        if size(Y, 1)==2
            X{1} = Y(1, t0:t1m);
            X{2} = Y(2, t0:t1m);
        else
            X{1} = Y(t0:t1m);
        end
        
    end
    
    for j = 1:4
        plot(X{j}', linestyles{j}, 'color', colors{j}, 'LineWidth', 2)
    end
    
    title(t(i),'interpreter','latex','FontSize',14)
    
    grid on
    if i==1
        if flag_epidemiological==1
            leg = {'Young', 'Old', 'Young (epidem.)', 'Old (epidem.)'};
        else
            if exist('SF','var')==1
                leg = {'Young', 'Old', 'Young (benchmark)', 'Old (benchmark)'};
            else
                leg = {'Young', 'Old'};
            end
        end
        
        legend(leg, ...
            'Orientation', 'horizontal', ...
            'Position', [0.5 0.9875 0 0], ... % [x y width height]
            'FontSize', 10)
    end
end

if exist('filename_fig_suffix', 'var')==1 && filename_fig_suffix~=""
    filename = strcat("results/figures/choices_r" ,filename_fig_suffix);
    saveas(gcf, filename, 'epsc')
end

%%
% 3: other
%%%%%%%%%%

figure
set(gcf, 'Position', fig_pos2);

s = ["pi_h_vec", "pi_f_vec", "pif_h_vec", "pif_f_vec", "gdp", "prior_vec"];
t = ["Prob. Covid-19 (healthy agent)", "Prob. Covid-19 (fever agent)", "Prob. fever (healthy agent)", "Prob. fever (fever agent)", "GDP", "Prior (healthy)"];

for i = 1:length(s)
    subplot(3,2,i)
    hold on
    
    X = cell(4, 1);
    
    eval(strcat("Y = ", s(i), ";"));
    t1m = min(t1, length(Y));
    
    if exist('SF','var')==1
        eval(strcat("Y0 = SF.", s(i), ";"));
        
        if size(Y, 1)==2
            if flag_epidemiological==1
                X{1} = Y0(1, t0:t1m);
                X{2} = Y0(2, t0:t1m);
                X{3} = Y(1, t0:t1m);
                X{4} = Y(2, t0:t1m);
            else
                X{1} = Y(1, t0:t1m);
                X{2} = Y(2, t0:t1m);
                X{3} = Y0(1, t0:t1m);
                X{4} = Y0(2, t0:t1m);
            end
        else
            if flag_epidemiological==1
                X{1} = Y0(t0:t1m);
                X{3} = Y(t0:t1m);
            else
                X{1} = Y(t0:t1m);
                X{3} = Y0(t0:t1m);
            end
        end
    else
        if size(Y, 1)==2
            X{1} = Y(1, t0:t1m);
            X{2} = Y(2, t0:t1m);
        else
            X{1} = Y(t0:t1m);
        end
        
    end
    
    for j = 1:4
        plot(X{j}', linestyles{j}, 'color', colors{j}, 'LineWidth', 2)
    end
    
    title(t(i),'interpreter','latex','FontSize',14)
    
    grid on
    if i==1
        if flag_epidemiological==1
            leg = {'Young', 'Old', 'Young (epidem.)', 'Old (epidem.)'};
        else
            if exist('SF','var')==1
                leg = {'Young', 'Old', 'Young (benchmark)', 'Old (benchmark)'};
            else
                leg = {'Young', 'Old'};
            end
        end
        
        legend(leg, ...
            'Orientation', 'horizontal', ...
            'Position', [0.5 0.9875 0 0], ... % [x y width height]
            'FontSize', 10)
    end
end

if exist('filename_fig_suffix', 'var')==1 && filename_fig_suffix~=""
    filename = strcat("results/figures/other" , filename_fig_suffix);
    saveas(gcf, filename, 'epsc')
end

%%

% close all

%%

%Figure to help with calibrating b
% m_d = 1-m_n-m_l;
% 
% figure
% set(gcf, 'Position', get(0, 'Screensize'));
% subplot(2,1,1)
% plot(d_h(:,1:20)', '-o', 'LineWidt', 2)
% title('d_h')
% grid on
% subplot(2,1,2)
% plot(d_h(:,1:20)'/m_d, '-o', 'LineWidt', 2)
% title('d_h/m_d')
% grid on
% 
% disp('d_h/m_d')
% disp([(1:20)',d_h(:,1:20)'/m_d])

% % growth rate of some masses
% s = ["M_i", "M_fi", "M_s", "M_i + M_fi + M_s"];
% TT = {"M_i", "M_{fi}", "M_s", "M_i + M_{fi} + M_s"};
% 
% figure
% 
% for i = 1:4
%     eval(strcat("X = ", s(i), ";"))
%     X = X';
%     
%     Y = zeros(T-1, n_age);
%     for i_age = 1:n_age
%         for t = 1:T-1
%             if X(t, i_age) > 1d-10
%                 Y(t, i_age) = (X(t+1, i_age) - X(t, i_age))/X(t, i_age);
%             else
%                 Y(t, i_age) = NaN;
%             end
%         end
%     end
%     subplot(2,2,i);
%     plot(Y, 'LineWidth', 2)
%     title(TT{i})
%     grid on
%     
%     if i==1
%         legend('Young', 'Old')
%     end
% end



close all
 


















