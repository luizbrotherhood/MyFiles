
% clears some variables
clear SB SP

lambda_p_i(:,:) = 0;
lambda_p_h(:,:) = 0;
lambda_p_r(:,:) = 0;
lambda_p_f(:,:) = 0;

xi_p(:) = 0;

descs = [];

count_fig = 0;

flag_append = 0;

%-------------------------------------------------------------------------%
%                                Benchmark                                %
%-------------------------------------------------------------------------%

disp("=========")
disp("Benchmark")
disp("=========")

% runs and saves results to csv
equilibrium
results

% saves some variables of benchmark
SB = struct('M_d', M_d, 'gdp', gdp, 'gdp_pc', gdp_pc, 't_peak_I', t_peak_I);
SP = struct('Pi', Pi, 'I', I, 'M_s', M_s);
SF = struct('M_h', M_h, 'M_fh', M_fh, 'M_fi', M_fi, 'M_f', M_f, 'M_i', M_i, 'M_s', M_s, 'M_r', M_r, 'M_d', M_d, 'I', I, 'c_h', c_h, 'n_h', n_h, 'l_h', l_h, 'x_h', x_h, 'd_h', d_h, 'c_f', c_f, 'n_f', n_f, 'l_f', l_f, 'x_f', x_f, 'd_f', d_f, 'pi_h_vec', pi_h_vec, 'pi_f_vec', pi_f_vec, 'pif_h_vec', pif_h_vec, 'pif_f_vec', pif_f_vec, 'gdp', gdp, 'prior_vec', prior_vec, 'v_h', v_h, 'c_i', c_i, 'n_i', n_i, 'l_i', l_i, 'x_i', x_i, 'd_i', d_i, 'v_i', v_i, 'c_r', c_r, 'n_r', n_r, 'l_r', l_r, 'x_r', x_r, 'd_r', d_r, 'v_r', v_r, 'v_f', v_f, 'gdp_pc', gdp_pc, 'Pi', Pi);

descs = [descs, "Benchmark"];

%-------------------------------------------------------------------------%
%                             Epidemiological                             %
%-------------------------------------------------------------------------%

disp("=======")
disp("Epidem.")
disp("=======")

flag_epidemiological = 1;

% runs and saves results to csv
equilibrium
results

% figures
count_fig = count_fig + 1;
filename_fig_suffix = strcat(filename_results_suffix, '_', num2str(count_fig));
figures

% turns off flag epidemiological
flag_epidemiological = 0;

descs = [descs, "Epidem."];

%-------------------------------------------------------------------------%
%                             Age ext. partial                            %
%-------------------------------------------------------------------------%

disp("================")
disp("Age ext. partial")
disp("================")

flag_Pi = 1;
flag_fake_young = 1;

% runs and saves results to csv
equilibrium
results

flag_Pi = 0;
flag_fake_young = 0;

descs = [descs, "Age ext. partial"];

%-------------------------------------------------------------------------%
%                             Age ext. general                            %
%-------------------------------------------------------------------------%

disp("================")
disp("Age ext. general")
disp("================")

flag_fake_young = 1;

% runs and saves results to csv
equilibrium
results

flag_fake_young = 0;

descs = [descs, "Age ext. general"];

%-------------------------------------------------------------------------%
%                             Selective mixing                            %
%-------------------------------------------------------------------------%

disp("================")
disp("Selective mixing")
disp("================")

% sets selective mixing
zeta = zeta_data;

% runs and saves results to csv
equilibrium
results

% figures
count_fig = count_fig + 1;
filename_fig_suffix = strcat(filename_results_suffix, '_', num2str(count_fig));
figures

% back without selective mixing
zeta = 0;

descs = [descs, "Sel. mix."];

%-------------------------------------------------------------------------%
%                                 Testing                                 %
%-------------------------------------------------------------------------%

disp("=======")
disp("Testing")
disp("=======")

testing_intensities = [0.25, 0.5, 0.75, 1];

for i_testing_intensity = 1:length(testing_intensities)
    testing_intensity = testing_intensities(i_testing_intensity);
    
    for i_who = 1:3
        if i_who==1 % all
            xi_p(:) = testing_intensity;
            who_string = "a";
        elseif i_who==2 % young
            xi_p(i_young) = testing_intensity;
            xi_p(i_old) = 0;
            who_string = "y";
        else % old
            xi_p(i_young) = 0;
            xi_p(i_old) = testing_intensity;
            who_string = "o";
        end

        desc = strcat("T-", who_string, "-", num2str(fix(100*testing_intensity)));
        
        I_want = ["T-a-100", "T-y-100", "T-o-100"];
        if ismember(desc, I_want)==0
            continue % if I want to skip some exercises
        end
        
        disp(desc)
        
        equilibrium
        results
        
        % figures
        if desc=="T-a-100"
            count_fig = count_fig + 1;
            filename_fig_suffix = strcat(filename_results_suffix, '_', num2str(count_fig));
            figures
        end
        
        descs = [descs, desc];
    end
end

%-------------------------------------------------------------------------%
%                                Quarantine                               %
%-------------------------------------------------------------------------%

disp("==========")
disp("Quarantine")
disp("==========")

new_lambdas = [9.7052372, 21.437848]; % 75%, 90% increase in d
testing_intensities = [0.5, 1]; % 50%, 100% testing

descs_new_lambda = ["75", "90"];

for i_new_lambda = 1:length(new_lambdas)
    new_lambda = new_lambdas(i_new_lambda);
    desc_new_lambda = descs_new_lambda(i_new_lambda);
    
    lambda_p_i(:,:) = max(new_lambda - lambda_i, 0);
    lambda_p_h(:,:) = 0;
    lambda_p_r(:,:) = 0;
    lambda_p_f(:,:) = 0;
    
    for i_testing_intensity = 1:length(testing_intensities)
        testing_intensity = testing_intensities(i_testing_intensity);
        
        for i_who = 1:3
            if i_who==1 % all
                xi_p(:) = testing_intensity;
                desc_who = "a";
            elseif i_who==2 % young
                xi_p(i_young) = testing_intensity;
                xi_p(i_old) = 0;
                desc_who = "y";
            else % old
                xi_p(i_young) = 0;
                xi_p(i_old) = testing_intensity;
                desc_who = "o";
            end
            
            desc = strcat("Q", desc_new_lambda, "-", desc_who, "-", num2str(floor(100*testing_intensity)), "t");
            
            I_want = ["Q90-a-50t", "Q90-a-100t", "Q90-y-100t"];
            if ismember(desc, I_want)==0
                continue % if I want to skip some exercises
            end
            
            disp(desc)
        
            % runs and saves results to csv
            equilibrium
            results
            
            % figures
            if desc=="Q90-a-50t"
                count_fig = count_fig + 1;
                filename_fig_suffix = strcat(filename_results_suffix, '_', num2str(count_fig));
                figures
            end
            
            descs = [descs, desc];
        end
    end
end

xi_p(:) = 0; % no more testing

%-------------------------------------------------------------------------%
%                             Shelter-at-home                             %
%-------------------------------------------------------------------------%

disp("===============")
disp("Shelter-at-home")
disp("===============")

new_lambdas = [2.572233, 4.502474, 9.7052372, 21.437848]; % 25, 50, 75%, 90% increase in d
durations = [4, 8, 12, 26, 35]; % weeks

descs_new_lambda = ["25", "50", "75", "90"];

for i_new_lambda = 1:length(new_lambdas)
    new_lambda = new_lambdas(i_new_lambda);
    desc_new_lambda = descs_new_lambda(i_new_lambda);

    for i_duration = 1:length(durations)
        duration = durations(i_duration);
        
        for i_who = 1:3 %all, y, o
            lambda_p_i(:,:) = 0;
            lambda_p_h(:,:) = 0;
            lambda_p_r(:,:) = 0;
            lambda_p_f(:,:) = 0;
            
            if i_who==1
                lambda_p_i(:, 1:duration) = max(new_lambda - lambda_i, 0);
                lambda_p_h(:, 1:duration) = max(new_lambda - lambda_h, 0);
                lambda_p_r(:, 1:duration) = max(new_lambda - lambda_h, 0);
                lambda_p_f(:, 1:duration) = max(new_lambda - lambda_h, 0);
                desc_who = "a";
            elseif i_who==2
                lambda_p_i(i_young, 1:duration) = max(new_lambda - lambda_i, 0);
                lambda_p_h(i_young, 1:duration) = max(new_lambda - lambda_h, 0);
                lambda_p_r(i_young, 1:duration) = max(new_lambda - lambda_h, 0);
                lambda_p_f(i_young, 1:duration) = max(new_lambda - lambda_h, 0);
                desc_who = "y";
            elseif i_who==3
                lambda_p_i(i_old, 1:duration) = max(new_lambda - lambda_i, 0);
                lambda_p_h(i_old, 1:duration) = max(new_lambda - lambda_h, 0);
                lambda_p_r(i_old, 1:duration) = max(new_lambda - lambda_h, 0);
                lambda_p_f(i_old, 1:duration) = max(new_lambda - lambda_h, 0);
                desc_who = "o";
            end
            
            desc = strcat("SH", desc_new_lambda, "-", desc_who, "-", num2str(floor(duration)));
            
            I_want = ["none"];
            if ismember(desc, I_want)==0
                continue % if I want to skip some exercises
            end
            
            disp(desc)

            % runs and saves results
            equilibrium
            results
            
            % figures
            if desc=="SH90-a-26"
                count_fig = count_fig + 1;
                filename_fig_suffix = strcat(filename_results_suffix, '_', num2str(count_fig));
                figures
            end
            
            descs = [descs, desc];
        end
    end
end

% clears lambda_p variables
lambda_p_i(:, :) = 0;
lambda_p_h(:, :) = 0;
lambda_p_r(:, :) = 0;
lambda_p_f(:, :) = 0;

% exports descriptions to a csv
cell2csv("descs.csv", cellstr(descs))








