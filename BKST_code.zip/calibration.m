

%-------------------------------------------------------------------------%
%                   Calibration 1: theta, gama, lambda_h                  %
%-------------------------------------------------------------------------%

data_targets = [m_x_over_n; m_n; m_l]; % [x/n; n; l]

% call solver
fun = @(param) calib(param, data_targets, 1, 1);
parameters = fminsearch(fun, [1 1 1]);

% defines parameters
theta = 0.5*(sin(parameters(1))+1);
gamma = exp(parameters(2));
lambda = exp(parameters(3));

% computes choices
[x, n, l, ~] = static_young(lambda, w, 0, 0, 0, 0);

% prints some info
fprintf('===========\n')
fprintf('Calibration\n')
fprintf('===========\n')

fprintf('theta = %.8g\n', theta)
fprintf('gamma = %.8g\n', gamma)
fprintf('lambda = %.8g\n', lambda)

K = zeros(3, 2);
K(:, 1) = data_targets;
K(:, 2) = [x/n; n; l];
K = array2table(K);
K.Properties.VariableNames = {'Data', ' Model'};
K.Properties.RowNames = {'x/n', ' n', 'l'};
disp(K)

%-------------------------------------------------------------------------%
%                     Calibration 2: n+l (time outside)                   %
%-------------------------------------------------------------------------%

for i = 1:3
    if i==1
        data_targets = (1-0.13)*(m_n+m_l); % (1-0.13)*(n+l)
    elseif i==2
        data_targets = (1-0.26)*(m_n+m_l); % (1-0.26)*(n+l)
    else
        data_targets = (1-0.52)*(m_n+m_l); % (1-0.52)*(n+l)
    end
    
    % call solver
    fun = @(param) calib(param, data_targets, 2, 2);
    parameters = fminsearch(fun, log(lambda));
    
    % defines parameters
    lambda = exp(parameters(1));
    
    % computes choices
    [~, n, l, ~] = static_young(lambda, w, 0, 0, 0, 0);
    
    % prints some info
    fprintf('===========\n')
    fprintf('Calibration\n')
    fprintf('===========\n')
    
    fprintf('lambda = %.8g\n', lambda)
    
    K = [data_targets, n+l];
    K = array2table(K);
    K.Properties.VariableNames = {'Data', ' Model'};
    K.Properties.RowNames = {'n+l'};
    disp(K)
end

%-------------------------------------------------------------------------%
%                   Calibration 3: 1-(n+l) (time inside)                  %
%-------------------------------------------------------------------------%

for i = 1:7
    if i==1
        data_targets = 1.1 * (1-(m_n+m_l));
    elseif i==2
        data_targets = 1.156 * (1-(m_n+m_l));
    elseif i==3
        data_targets = 1.25 * (1-(m_n+m_l));
    elseif i==4
        data_targets = 1.50 * (1-(m_n+m_l));
    elseif i==5
        data_targets = 1.67 * (1-(m_n+m_l));
    elseif i==6
        data_targets = 1.75 * (1-(m_n+m_l));
    else
        data_targets = 1.90 * (1-(m_n+m_l));
    end

    % call solver
    fun = @(param) calib(param, data_targets, 2, 3);
    parameters = fminsearch(fun, log(lambda));
    
    % defines parameter
    lambda = exp(parameters(1));
    
    % computes choices
    [~,n,l,~] = static_young(lambda, w, 0, 0, 0, 0);

    % prints some info
    fprintf('===========\n')
    fprintf('Calibration\n')
    fprintf('===========\n')
    
    fprintf('lambda = %.8g\n', lambda)
    
    K = [data_targets, 1-(n+l)];
    K = array2table(K);
    K.Properties.VariableNames = {'Data', ' Model'};
    K.Properties.RowNames = {'d'};
    disp(K)
end

%-------------------------------------------------------------------------%
%                           Internal functions                            %
%-------------------------------------------------------------------------%

function out = calib(param, data_targets, i_param, i_target)
    % i_param = 1: calibrates theta, gamma, and lambda
    % i_param = 2: calibrates lambda
    
    % i_target = 1: fits x/n, n, and l
    % i_target = 2: fits n+l
    % i_target = 3: fits 1-(n+l)
    
    global w gamma theta
    
    % defines parameters
    if i_param==1
        theta = 0.5*(sin(param(1))+1);
        gamma = exp(param(2));
        lambda = exp(param(3));
    elseif i_param==2
        lambda = exp(param(1));
    else
        error('no such i_param')
    end
    
    % solves problem of young
    [x, n, l, ~] = static_young(lambda, w, 0, 0, 0, 0);
    
    % targets
    if i_target==1
        model_targets = [x/n; n; l];
    elseif i_target==2
        model_targets = n+l;
    elseif i_target==3
        model_targets = 1-(n+l);
    else
        error('no such i_target')
    end
    
    % computes distance between data and model
    out = sum((data_targets - model_targets).^2);
    
end









