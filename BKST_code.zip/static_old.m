function [x,l,d] = static_old(lambda, discount, CV_diff1, CV_diff2, Pi_today)

%This m-file solves the static problem of an old agent

global gamma theta rho wbar i_old xi_p Pistar x_ub_old

CV = discount*xi_p(i_old)*Pi_today*CV_diff1 + ...
     discount*(1-xi_p(i_old))*(Pi_today+Pistar)*CV_diff2;

l_hat = @(x) (theta/(1-theta) * (wbar*gamma*x^(rho-1) - (1+gamma)*x^rho))^(1/rho);

foc = @(x) gamma*(1-theta)*l_hat(x)^(rho-1)/(theta*x^rho+(1-theta)*l_hat(x)^rho) - ...
    lambda/(1-l_hat(x)) + CV;

x = fzero(foc, [0.0001, x_ub_old]);
l = l_hat(x);
d = 1-l;