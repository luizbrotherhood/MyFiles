
close all

color_y = [0, 0.4470, 0.7410]; % blue
color_o = [0.8500, 0.3250, 0.0980]; % red

% color_y = [35/250,55/250,59/250]; % metropolis beamer theme
% color_o = [235/250,129/250,27/250]; % metropolis beamer theme

colors = {color_y; color_o; color_y; color_o};
linestyles = {"-", "-", "--", "--"};

if exist('t0_fig', 'var')==1 && exist('t1_fig', 'var')==1
    t0 = t0_fig;
    t1 = t1_fig;
else
    t0 = 1; % first t to plot
    t1 = 150; % last t to plot
end

%% aggregates

s = ["M_fi", "M_i", "M_s", "M_i_all", "M_d", "gdp"];
t = ["Measure, fever-infected ($M_{fi}$)", "Measure, infected ($M_{i}$)", "Measure, serious symptoms ($M_{s}$)", "Measure, all infected ($M_{fi} + M_{i} + M_{s}$)", "Measure, deceased ($M_d$)", "GDP"];

fig_pos = [10, 50, 1280, 500];

figure
set(gcf, 'Position', fig_pos);

for i = 1:length(s)
    subplot(2, 3, i)
    hold on
    
    X = cell(4, 1);
    
    eval(strcat("Y = ", s(i), ";"));
    t1m = min(t1, length(Y));
    
    if exist('SF','var')==1
        eval(strcat("Y0 = SF.", s(i), ";"));
        
        if size(Y, 1)==2
            if flag_epidemiological==1
                X{1} = Y0(1, t0:t1m);
                X{2} = Y0(2, t0:t1m);
                X{3} = Y(1, t0:t1m);
                X{4} = Y(2, t0:t1m);
            else
                X{1} = Y(1, t0:t1m);
                X{2} = Y(2, t0:t1m);
                X{3} = Y0(1, t0:t1m);
                X{4} = Y0(2, t0:t1m);
            end
        else
            if flag_epidemiological==1
                X{1} = Y0(t0:t1m);
                X{3} = Y(t0:t1m);
            else
                X{1} = Y(t0:t1m);
                X{3} = Y0(t0:t1m);
            end
        end
    else
        if size(Y, 1)==2
            X{1} = Y(1, t0:t1m);
            X{2} = Y(2, t0:t1m);
        else
            X{1} = Y(t0:t1m);
        end
        
    end
    
    for j = 1:4
        plot(X{j}', linestyles{j}, 'color', colors{j}, 'LineWidth', 2)
    end
    
    title(t(i),'interpreter','latex','FontSize',14)
    
    grid on
    if i==1
        if flag_epidemiological==1
            leg = {'Young', 'Old', 'Young (epidem.)', 'Old (epidem.)'};
        else
            if exist('SF','var')==1
                leg = {'Young', 'Old', 'Young (benchmark)', 'Old (benchmark)'};
            else
                leg = {'Young', 'Old'};
            end
        end
        
%         legend(leg, 'interpreter', 'latex', 'fontsize', 10)
        
        legend(leg, ...
            'Orientation', 'horizontal', ...
            'Position', [0.5 0.025 0 0], ... % [x y width height]
            'FontSize', 12, 'interpreter', 'latex')
    end
end

if exist('filename_fig_suffix', 'var')==1 && filename_fig_suffix~=""
    filename = strcat("results/figures_paper/aggregates", filename_fig_suffix);
    saveas(gcf, filename, 'epsc')
end

%% choices_h

fig_pos = [10, 50, 1280, 325]; % smaller figure

s = ["d_h", "n_h", "l_h"];
t = ["Time at home ($d_h$)", " Time at work ($n_h$)", "Leisure outsite ($\ell_h$)"];

pos_vec = zeros(3, 4);

% gets some information from standard subplot
figure
set(gcf, 'position', fig_pos)

for i = 1:3
    handle = subplot(1, 3, i);
    pos_vec(i, :) = get(handle, 'position');    
end

close

% adjusts some properties of subplot
pos_vec(:, 2) = pos_vec(:, 2) * 1.75;
pos_vec(:, 4) = pos_vec(:, 4) * 0.85; % height

% makes figures
figure
set(gcf, 'Position', fig_pos);

for i = 1:length(s)
    subplot('position', pos_vec(i, :))
    hold on
    
    X = cell(4, 1);
    
    eval(strcat("Y = ", s(i), ";"));
    t1m = min(t1, length(Y));
    
    if exist('SF','var')==1
        eval(strcat("Y0 = SF.", s(i), ";"));
        
        if size(Y, 1)==2
            if flag_epidemiological==1
                X{1} = Y0(1, t0:t1m);
                X{2} = Y0(2, t0:t1m);
                X{3} = Y(1, t0:t1m);
                X{4} = Y(2, t0:t1m);
            else
                X{1} = Y(1, t0:t1m);
                X{2} = Y(2, t0:t1m);
                X{3} = Y0(1, t0:t1m);
                X{4} = Y0(2, t0:t1m);
            end
        else
            if flag_epidemiological==1
                X{1} = Y0(t0:t1m);
                X{3} = Y(t0:t1m);
            else
                X{1} = Y(t0:t1m);
                X{3} = Y0(t0:t1m);
            end
        end
    else
        if size(Y, 1)==2
            X{1} = Y(1, t0:t1m);
            X{2} = Y(2, t0:t1m);
        else
            X{1} = Y(t0:t1m);
        end
        
    end
    
    for j = 1:4
        plot(X{j}', linestyles{j}, 'color', colors{j}, 'LineWidth', 2)
    end
    
    title(t(i),'interpreter','latex','FontSize',14)
    
    grid on
    if i==2
        if flag_epidemiological==1
            leg = {'Young', 'Old', 'Young (epidem.)', 'Old (epidem.)'};
        else
            if exist('SF','var')==1
                leg = {'Young', 'Old', 'Young (benchmark)', 'Old (benchmark)'};
            else
                leg = {'Young', 'Old'};
            end
        end
        
%         legend(leg, 'interpreter', 'latex', 'fontsize', 10, 'location', 'east')
        
        legend(leg, ...
            'Orientation', 'horizontal', ...
            'Position', [0.5 0.06 0 0], ... % [x y width height]
            'FontSize', 12, 'interpreter', 'latex')
    end
end

if exist('filename_fig_suffix', 'var')==1 && filename_fig_suffix~=""
    filename = strcat("results/figures_paper/choices_h", filename_fig_suffix);
    saveas(gcf, filename, 'epsc')
end

% close all









